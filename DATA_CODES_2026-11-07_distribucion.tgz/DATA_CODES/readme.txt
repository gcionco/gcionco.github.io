HOLOCENE PROXY AND INSOLATION CURVE ANALYSES
--------------------------------------------
AUTHOR: R. G. CIONCO, November 2026

DATA FILES
----------
DATA/PROXIES/*-NORM.dat: proxy Z scores calculated by the author from the raw data.
DATA/FORCINGS/F#_*.dat: centennial orbital forcing curves supplied
by the author.

ANALYSES 
--------
FILTERING: filtered and re-standardized proxy trends.
CORRELATIONS: moving Pearson/Spearman coefficients and bootstrap bounds.
RECONSTRUCTION: out--of--sample proxy reconstructions, Q and  MSE.
RECONSTRUCTION/MONTE_CARLO: surrogate analysis and family-wise probabilities.
The figures/ directories contain GNUPLOT scripts and their PDF outputs.

Each statistical analysis has local input/output files.
Each run.dat defines the parameters, cases and files used by its program.


