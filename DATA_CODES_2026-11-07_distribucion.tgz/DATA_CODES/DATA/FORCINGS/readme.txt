FORCING CURVES
--------------

Files in DATA/FORCINGS/ contain time [ka BP1950] and forcing Z score.
They start at 1950 CE (0 BP1950), proceeding backward every 100 years.
These author-supplied inputs are used by the time-domain plots and statistics.
DW denotes mean insolation; MIG is the difference between the listed latitudes.

  F01_DW30S_DJF.dat          summer insolation at 30S.
  F02_DW30S_SON_DJF.dat      spring+summer insolation at 30S.
  F03_DW30S_DJF_MAM.dat      summer+autumn insolation at 30S.
  F04_DW30S_S_DJF_M.dat      September-March insolation at 30S.
  F05_MIG0_30S_DJF.dat       summer MIG, 0 minus 30S.
  F06_MIG30S_30N_DJF.dat     summer MIG, 30S minus 30N.
  F07_MIG30S_60S_DJF.dat     summer MIG, 30S minus 60S.
  F08_DW60S_DJF.dat          summer insolation at 60S.
  F09_DW60S_MAM_JJA.dat      autumn+winter insolation at 60S.
  F10_MIG30S_60S_JJA.dat     winter MIG, 30S minus 60S.
  F11_DW60S_SON.dat          spring insolation at 60S.
