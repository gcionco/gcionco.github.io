PROXY RECORDS
--------------

Files in DATA/PROXIES/ contain two columns: age [ka BP1950] and proxy Z score.
BP1950 refers to 1950 CE; ages increase toward the past. Sampling is irregular.
These are input Z scores calculated by R. G. Cionco from the original proxy data.


  P01  BTV2-Cruz-D18O-NORM.dat
       Botuvera Cave BTV2 speleothem delta18O, Cruz et al. (2005).
       Revised chronology: Cruz et al. (2009); provided by C. M. Chiessi.

  P02  BTV3A-Wang-D18O-NORM.dat
       Botuvera Cave BTV3A speleothem delta18O, Wang et al. (2007).

  P03  GeOB6211-2-AlSi-NORM.dat
       Marine core GeoB6211-2 Al/Si ratio, Chiessi et al. (2010).

  P04  GeoB6211-2-Fe-NORM.dat
       Marine core GeoB6211-2 Fe concentration, Razik et al. (2013).

  P05  CaCo3-Lamy-NORM.dat
       Palm2 biogenic CaCO3 accumulation rate, Lamy et al. (2010).

  P06  Notofagus-NORM.dat
       Laguna Azul Nothofagus dombeyi-type pollen percentage,
       Zolitschka et al. (2019).

