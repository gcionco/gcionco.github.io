#!/usr/bin/gnuplot
# Palm2 proxy/forcing comparison.
# INPUT
#   ../output/proxies/P05_PALM2_CACO3_Z.dat;
#   F08,F09,F10 files.
# OUTPUT
#   FIG5.pdf.

if (exists("ARG0")) {
    plot_directory = ""
    do for [path_position = strlen(ARG0):1:-1] {
        if (ARG0[path_position:path_position] eq "/" && strlen(plot_directory) == 0) {
            plot_directory = ARG0[1:path_position]
        }
    }
    if (strlen(plot_directory) > 0) {
        cd plot_directory
    }
}

# Paper time-domain proxy/IC comparison.
# Input tables keep their original signs; sign reversals are applied in using expressions.
set terminal pdfcairo enhanced color font "Nimbus Roman,16" size 5in,3in
set encoding utf8
set datafile commentschars "#"
set xrange [0:11]
set yrange [-5:5]
set xtics 1 font ",14"
set ytics font ",14"
set xlabel "Time [kyBP]" font ",16"
set ylabel "<-- DRIER    Z score    WETTER -->" font ",16"
set xzeroaxis
set key top right font ",13"
set pointsize 0.5
set label 1 "↓  -Intensity of SWW at southwestern Patagonia" at 2,-3 font ",16"

data = "../output/proxies/P05_PALM2_CACO3_Z.dat"

set output "FIG5.pdf"
plot data u 1:(-$2) title "-CaCO_3 (Palm2, 52.79°S, 73.65°W; Lamy et al., 2010)" w lp pt 7 ps 0.4 lc rgb "green", \
     "F09_DW60S_MAM_JJA.dat" u 1:2 title "ΔW_{(60°S,MAM+JJA)}" w l lw 2 lc rgb "black", \
     "F10_MIG30S_60S_JJA.dat" u 1:2 title "MIG_{(30°S-60°S,JJA)}" w l lw 2 lc rgb "blue", \
     "F08_DW60S_DJF.dat" u 1:(-$2) title "-ΔW_{(60°S,DJF)}" w l lw 2 lc rgb "red"
unset output
