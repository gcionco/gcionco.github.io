#!/usr/bin/gnuplot
# Laguna Azul proxy/forcing comparison.
# INPUT
#   ../output/proxies/P06_LAGUNAAZUL_NOTHOFAGUS_Z.dat;
#   F09,F11,F10 files.
# OUTPUT
#   FIG6.pdf.

if (exists("ARG0")) {
    plot_directory = ""
    do for [path_position = strlen(ARG0):1:-1] {
        if (ARG0[path_position:path_position] eq "/" && strlen(plot_directory) == 0) {
            plot_directory = ARG0[1:path_position]
        }
    }
    if (strlen(plot_directory) > 0) {
        cd plot_directory
    }
}

# Paper time-domain proxy/IC comparison.
# Input tables keep their original signs; sign reversals are applied in using expressions.
set terminal pdfcairo enhanced color font "Nimbus Roman,16" size 5in,3in
set encoding utf8
set datafile commentschars "#"
set xrange [0:11]
set yrange [-5:5]
set xtics 1 font ",14"
set ytics font ",14"
set xlabel "Time [kyBP]" font ",16"
set ylabel "<-- DRIER    Z score    WETTER -->" font ",16"
set xzeroaxis
set key top right font ",13"
set pointsize 0.5
set label 1 "↑ -Westerlies, -Nothofagus pollen" at 5,-3 font ",16"

data = "../output/proxies/P06_LAGUNAAZUL_NOTHOFAGUS_Z.dat"

set output "FIG6.pdf"
plot data u 1:(-$2) title "-Nothofagus pollen (LA, 52.08°S, 69.6°W; Zolitschka et al., 2019)" w lp pt 7 ps 0.4 lc rgb "green", \
     "F09_DW60S_MAM_JJA.dat" u 1:(-$2) title "-ΔW_{(60°S,MAM+JJA)}" w l lw 2 lc rgb "black", \
     "F11_DW60S_SON.dat" u 1:2 title "ΔW_{(60°S,SON)}" w l lw 2 lc rgb "orange", \
     "F10_MIG30S_60S_JJA.dat" u 1:(-$2) title "-MIG_{(30°S-60°S,JJA)}" w l lw 2 lc rgb "blue"
unset output
