#!/usr/bin/gnuplot
# GeoB6211-2 proxy/forcing comparison.
# INPUT
#   ../output/proxies/P03_GEOB_ALSI_Z.dat and P04_GEOB_FE_Z.dat;
#   F01,F02,F03,F07 files.
# OUTPUT
#   FIG4.pdf.

if (exists("ARG0")) {
    plot_directory = ""
    do for [path_position = strlen(ARG0):1:-1] {
        if (ARG0[path_position:path_position] eq "/" && strlen(plot_directory) == 0) {
            plot_directory = ARG0[1:path_position]
        }
    }
    if (strlen(plot_directory) > 0) {
        cd plot_directory
    }
}

# Paper time-domain proxy/IC comparison.
# Input tables keep their original signs; sign reversals are applied in using expressions.
set terminal pdfcairo enhanced color font "Nimbus Roman,16" size 5in,3in
set encoding utf8
set datafile commentschars "#"
set xrange [0:11]
set yrange [-5:5]
set xtics 1 font ",14"
set ytics font ",14"
set xlabel "Time [kyBP]" font ",16"
set ylabel "<-- DRIER    Z score    WETTER -->" font ",16"
set xzeroaxis
set key top right font ",13"
set pointsize 0.5
set label 1 "↑  + Rainfall + La Plata River sediments" at 3,-2.5 font ",16"

fe   = "../output/proxies/P04_GEOB_FE_Z.dat"
alsi = "../output/proxies/P03_GEOB_ALSI_Z.dat"

set output "FIG4.pdf"
plot fe u 1:2 title "Fe (GeOB6211-2, 32.50°S, 50.24°W; Razik et al., 2013)" w lp pt 7 ps 0.4 lc rgb "green", \
     alsi u 1:2 title "Al/Si (GeOB6211-2, 32.50°S, 50.24°W; Chiessi et al., 2010) " w lp pt 7 ps 0.4 lc rgb "cyan", \
     "F02_DW30S_SON_DJF.dat" u 1:2 title "ΔW_{(30°S,SON+DJF)}" w l lw 2 lc rgb "orange", \
     "F03_DW30S_DJF_MAM.dat" u 1:2 title "ΔW_{(30°S,DJF+MAM)}" w l lw 2 lc rgb "black", \
     "F01_DW30S_DJF.dat" u 1:2 title "ΔW_{(30°S,DJF)}" w l lw 2 lc rgb "red", \
     "F07_MIG30S_60S_DJF.dat" u 1:2 title "MIG_{(30°S-60°S,DJF)}" w l lw 2 lc rgb "gray"

unset output
