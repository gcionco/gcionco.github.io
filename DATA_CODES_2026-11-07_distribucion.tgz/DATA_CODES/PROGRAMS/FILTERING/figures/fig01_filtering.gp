#!/usr/bin/gnuplot
# Gaussian filtering figure.
# INPUT
#   *-NORM.dat and ../output/proxies/proxies_smooth.sal.
#   The combined table is the filtered series before re-standardization.
# OUTPUT
#   FIG1.pdf.

if (exists("ARG0")) {
    plot_directory = ""
    do for [path_position = strlen(ARG0):1:-1] {
        if (ARG0[path_position:path_position] eq "/" && strlen(plot_directory) == 0) {
            plot_directory = ARG0[1:path_position]
        }
    }
    if (strlen(plot_directory) > 0) {
        cd plot_directory
    }
}

# Paper Figure 1: original input Z scores and Gaussian-filtered curves.
# The red curve is before the post-filter re-standardization; this is intentional.
set encoding utf8
set datafile commentschars "#"
set datafile missing "NaN"
set decimalsign locale "C"
set border linewidth 0.8
set tics in nomirror
set tics font "Nimbus Roman,24"
set key font "Nimbus Roman,24"
set key top center
set title font "Nimbus Roman,26"
set xlabel font "Nimbus Roman,32"
set ylabel font "Nimbus Roman,32"
set xtics 2
set mxtics 2
set grid ytics lc rgb "#dddddd" lw 0.5
set xzeroaxis dt 2 lw 1.0 lc rgb "#707070"
set xrange [0:11.0]
unset xlabel
set ylabel "Z score" font "Nimbus Roman,32"

filtered = "../output/proxies/proxies_smooth.sal"


set terminal pdfcairo enhanced color font "Nimbus Roman,24" size 21cm,29.7cm
set output "FIG1.pdf"
set multiplot layout 3,2 rowsfirst margins 0.12,0.98,0.07,0.95 spacing 0.08,0.08
set style textbox 1 opaque margins 0.5,0.5 border lc rgb "#202020" lw 0.8 fillcolor rgb "white"

set label 1 "(a)" left at graph 0.03,0.93 front boxed bs 1 font "Nimbus Roman,24"
set title "BTV2: {/Symbol d}^{18}O"
plot "BTV2-Cruz-D18O-NORM.dat" using 1:2 with linespoints lw 0.8 pt 7 ps 0.28 lc rgb "#808080" title "Original", \
     filtered using 1:2 with lines lw 2.0 lc rgb "#b2182b" title "Filtered"

set label 1 "(b)" left at graph 0.03,0.93 front boxed bs 1 font "Nimbus Roman,24"
set title "BTV3A: {/Symbol d}^{18}O"
unset ylabel
plot "BTV3A-Wang-D18O-NORM.dat" using 1:2 with linespoints lw 0.8 pt 7 ps 0.30 lc rgb "#808080" notitle, \
     filtered using 1:3 with lines lw 2.0 lc rgb "#b2182b" notitle

set label 1 "(c)" right at graph 0.97,0.93 front boxed bs 1 font "Nimbus Roman,24"
set title "GeoB6211-2: Al/Si"
set ylabel "Z score" font "Nimbus Roman,32"
plot "GeOB6211-2-AlSi-NORM.dat" using 1:2 with linespoints lw 0.8 pt 7 ps 0.22 lc rgb "#808080" notitle, \
     filtered using 1:4 with lines lw 2.0 lc rgb "#b2182b" notitle

set label 1 "(d)" center at graph 0.50,0.93 front boxed bs 1 font "Nimbus Roman,24"
set title "GeoB6211-2: Fe"
unset ylabel
plot "GeoB6211-2-Fe-NORM.dat" using 1:2 with linespoints lw 0.8 pt 7 ps 0.32 lc rgb "#808080" notitle, \
     filtered using 1:5 with lines lw 2.0 lc rgb "#b2182b" notitle

set xlabel "Time [kyBP]" font "Nimbus Roman,32"
set label 1 "(e)" right at graph 0.97,0.93 front boxed bs 1 font "Nimbus Roman,24"
set title "Palm2: CaCO_{3}"
set ylabel "Z score" font "Nimbus Roman,32"
plot "CaCo3-Lamy-NORM.dat" using 1:2 with linespoints lw 0.8 pt 7 ps 0.30 lc rgb "#808080" notitle, \
     filtered using 1:6 with lines lw 2.0 lc rgb "#b2182b" notitle

set label 1 "(f)" right at graph 0.97,0.93 front boxed bs 1 font "Nimbus Roman,24"
set title "LA: {/NimbusRoman-Italic Nothofagus}"
unset ylabel
plot "Notofagus-NORM.dat" using 1:2 with linespoints lw 0.8 pt 7 ps 0.22 lc rgb "#808080" notitle, \
     filtered using 1:7 with lines lw 2.0 lc rgb "#b2182b" notitle

unset multiplot
unset output
