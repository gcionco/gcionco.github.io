PROXY FILTERING AND TREND RE-STANDARDIZATION
--------------------------------------------

Edit run.dat to set paths, sigma, grid step, age limits and proxy filenames.
Each proxy row gives input_file, output_file, value_column and skip_header.
skip_header: T = true, skip the first line; F = false, read from the first line.


INPUT
input/*-NORM.dat: copies from ../../DATA/PROXIES/; age [ka BP1950] and proxy Z score.

OUTPUT
Each output table includes # Column N = ... lines defining its columns.
output/proxies/P*.dat: age and filtered, re-standardized trend Z score.
Re-standardization uses the analysis interval and sample standard deviation.
Each file starts with # Time[ka_BP1950] Pxx, where Pxx identifies the proxy below.

output/proxies/proxies_smooth.sal: age plus the six filtered curves before
re-standardization, in run.dat order. This is the input for FIG1.pdf.
Its header is # Time[ka_BP1950] P01 P02 P03 P04 P05 P06 for the supplied run.dat.

PROXY IDENTIFIERS
P01: BTV2, Botuvera Cave delta18O; Cruz et al. (2005), chronology Cruz et al. (2009).
P02: BTV3A, Botuvera Cave delta18O; Wang et al. (2007).
P03: GeoB6211-2 Al/Si; Chiessi et al. (2010).
P04: GeoB6211-2 Fe; Razik et al. (2013).
P05: Palm2 biogenic CaCO3 accumulation rate; Lamy et al. (2010).
P06: Laguna Azul Nothofagus dombeyi-type pollen; Zolitschka et al. (2019).

FIGURES
From figures/, run the corresponding GNUPLOT script:
  ./fig01_filtering.gp          FIG1.pdf: input proxies and filtered curves.
  ./time_domain_botuvera.gp     FIG2.pdf and FIG3.pdf.
  ./time_domain_geob.gp         FIG4.pdf.
  ./time_domain_palm2.gp        FIG5.pdf.
  ./time_domain_laguna_azul.gp   FIG6.pdf.

The GNUPLOT scripts read the filtering results directly from output/proxies/.
Accessory data are supplied alongside the GNUPLOT scripts in figures/:
  *-NORM.dat: copies of input/*-NORM.dat for FIG1.pdf.
  F*.dat: copies of ../../DATA/FORCINGS/F*.dat for FIG2.pdf to FIG6.pdf.
The GNUPLOT scripts read these local copies.
The forcing files are used only for plotting.

