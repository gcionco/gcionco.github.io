! Gaussian filtering and re-standardization of proxy trends on a regular age grid.
! INPUT
!   run.dat: paths, sigma, grid step, age limits, file names and column options.
!   input/*.dat: irregular proxy series; age [ka BP1950], author-calculated Z score.
! OUTPUT
!   output/proxies/P*.dat: age and filtered trend, re-standardized over the analysis interval.
!   proxies_smooth.sal: input for FIG1.pdf; age plus filtered curves before re-standardization.
!
! AUTHOR: R. G. CIONCO, 2026.
!--------------------------------------------------------------------------------

program filter_ssa_proxies

  implicit none

!...Constants and run parameters
  real*8, parameter :: pi=4.d0 * DATAN(1.d0)
  real*8 :: sigma,grid_step
  real*8 :: analysis_start,analysis_end,retained_end

!...Dimensions and counters
  integer :: n_proxy,n_grid,n_paper_grid
  integer :: max_points,max_records,records
  integer :: i,j,config_unit,input_unit,ios
  integer, allocatable :: value_column(:),n_data(:)
  logical, allocatable :: skip_header(:)

!...Input/output files
  character(len=512) :: base_directory, output_directory
  character(len=1024) :: output_file, input_file
  character(len=1024) :: executable,control_directory,line,first_table
  character(len=128), allocatable :: relative_path(:),output_names(:)

!...Data arrays: observations, age grid and filtered curves
  real*8, allocatable :: time(:,:)
  real*8, allocatable :: zscore(:,:)
  real*8, allocatable :: grid(:)
  real*8, allocatable :: filtered(:,:)
  real*8, allocatable :: filtered_z(:,:)
  logical, allocatable :: valid(:,:)

!...Read run.dat beside the executable
  call get_command_argument(0,executable)
  i=scan(trim(executable),'/',back=.true.)
  control_directory='.'
  if (i>0) control_directory=executable(:i)

  open(newunit=config_unit,file=trim(control_directory)//'/run.dat',status='old', &
    action='read',iostat=ios)
  if (ios/=0) error stop 'Cannot open run.dat beside the executable.'

  call control_line(config_unit,line)
  base_directory=resolve_path(trim(line))

  call control_line(config_unit,line)
  output_directory=resolve_path(trim(line))

  call control_line(config_unit,line)
  read(line,*,iostat=ios) sigma,grid_step,analysis_start,analysis_end,retained_end
  if (ios/=0) error stop 'Invalid filter parameters in run.dat.'
  if (sigma<=0.d0 .or. grid_step<=0.d0) &
    error stop 'Sigma and grid step must be positive.'
  if (analysis_end<=analysis_start .or. retained_end<analysis_end) &
    error stop 'Invalid age limits.'

  ! Number of ages on the retained grid and within the analysis interval.
  n_grid=nint((retained_end-analysis_start)/grid_step)+1
  n_paper_grid=nint((analysis_end-analysis_start)/grid_step)+1
  if (abs(analysis_start+dble(n_grid-1)*grid_step-retained_end)>1.d-8) &
    error stop 'Retained age range must span whole grid steps.'
  if (abs(analysis_start+dble(n_paper_grid-1)*grid_step-analysis_end)>1.d-8) &
    error stop 'Analysis age range must span whole grid steps.'

  call control_line(config_unit,line)
  read(line,*,iostat=ios) first_table
  if (ios/=0) error stop 'Invalid output table names.'
  output_file=trim(output_directory)//'/'//trim(first_table)

  call control_line(config_unit,line)
  read(line,*,iostat=ios) n_proxy
  if (ios/=0 .or. n_proxy<1) error stop 'Invalid proxy count.'

  allocate(relative_path(n_proxy),output_names(n_proxy))
  allocate(value_column(n_proxy),n_data(n_proxy))
  allocate(skip_header(n_proxy))

  do i=1,n_proxy
    call control_line(config_unit,line)
    read(line,*,iostat=ios) relative_path(i),output_names(i),value_column(i),skip_header(i)
    if (ios/=0) error stop 'Invalid proxy definition in run.dat.'
  end do

  close(config_unit)

!...Count input records to obtain the array dimensions
  max_records=0

  do i=1,n_proxy
    open(newunit=input_unit,file=trim(base_directory)//'/'//trim(relative_path(i)), &
      status='old',action='read',iostat=ios)
    if (ios/=0) error stop 'Cannot open an input proxy listed in run.dat.'

    records=0
    do
      read(input_unit,'(a)',iostat=ios) line
      if (ios/=0) exit
      records=records+1
    end do

    close(input_unit)
    max_records=max(max_records,records)
  end do

  if (max_records<1) error stop 'Empty proxy inputs.'
  max_points=max_records

!...Allocate observation and grid arrays
  allocate(time(max_points,n_proxy))
  allocate(zscore(max_points,n_proxy))
  allocate(grid(n_grid))
  allocate(filtered(n_grid,n_proxy))
  allocate(filtered_z(n_grid,n_proxy))
  allocate(valid(n_grid,n_proxy))

  time = 0.d0
  zscore = 0.d0
  filtered = 0.d0
  filtered_z = 0.d0
  valid = .false.

!...Regular age grid, in ka BP1950
  do j = 1, n_grid
    grid(j) = analysis_start+dble(j-1)*grid_step
  end do

!...Read and filter each proxy
  do i = 1, n_proxy
    input_file = trim(base_directory)//'/'//trim(relative_path(i))
    call read_proxy(trim(input_file), &
                    value_column(i), skip_header(i), &
                    time(:,i), zscore(:,i), n_data(i))

    call gaussian_filter(time(:,i), zscore(:,i), n_data(i), grid, &
                         filtered(:,i), valid(:,i))

    write(*,'(A,I8,A,A)') 'Read ', n_data(i), ' data from ', &
                           trim(relative_path(i))
  end do

!...Re-standardize the filtered curves over the analysis interval
  call standardize_filtered(filtered, valid, filtered_z)

!...Write the combined table and the individual proxy files
  call ensure_output_directory(trim(output_directory))
  call write_output(trim(output_file), grid, filtered, valid)
  write(*,'(A)') 'Created '//trim(output_file)
  call write_individual_outputs(trim(output_directory),grid,filtered_z,valid)

contains

!-------------------------------------------------------------------------------
  ! Read the supplied irregular input Z scores; preserve their signs.
  ! Non-numeric records are skipped. Ages and values are stored without interpolation.
  subroutine read_proxy(filename, value_column, skip_header, &
                        time, zscore, n_data)
    implicit none

    character(len=*), intent(in) :: filename
    integer, intent(in) :: value_column
    logical, intent(in) :: skip_header
    real*8, intent(out) :: time(max_points), zscore(max_points)
    integer, intent(out) :: n_data

    integer :: unit_in, io_status
    real*8 :: column_1, column_2, column_3
    character(len=512) :: line

    unit_in = 10
    n_data = 0
    time = 0.d0
    zscore = 0.d0

    open(unit=unit_in, file=trim(filename), status='old', action='read', &
         iostat=io_status)
    if (io_status /= 0) then
      write(*,'(A)') 'ERROR: cannot open '//trim(filename)
      stop 1
    end if

    if (skip_header) read(unit_in,'(A)',iostat=io_status) line

    do
      read(unit_in,'(A)',iostat=io_status) line
      if (io_status /= 0) exit
      if (len_trim(line) == 0) cycle
      line = adjustl(line)
      if (line(1:1) == '#' .or. line(1:1) == '!') cycle

      if (value_column == 2) then
        read(line,*,iostat=io_status) column_1, column_2
        if (io_status /= 0) cycle
      else if (value_column == 3) then
        read(line,*,iostat=io_status) column_1, column_2, column_3
        if (io_status /= 0) cycle
      else
        write(*,'(A)') 'ERROR: value_column must be 2 or 3.'
        stop 1
      end if

      n_data = n_data + 1
      if (n_data > max_points) then
        write(*,'(A)') 'ERROR: max_points is too small.'
        stop 1
      end if

      time(n_data) = column_1
      if (value_column == 2) then
        zscore(n_data) = column_2
      else
        zscore(n_data) = column_3
      end if
    end do

    close(unit_in)
  end subroutine read_proxy

!-------------------------------------------------------------------------------
  ! Evaluate the normalized Gaussian weighted mean on the centennial grid.
  ! For targets in 0--11 ka BP, exclude observations older than 11 ka BP.
  ! Include all retained Gaussian weights; no gap-rejection threshold is imposed.
  subroutine gaussian_filter(time, zscore, n_data, grid, filtered, valid)
    implicit none

    integer, intent(in) :: n_data
    real*8, intent(in) :: time(max_points), zscore(max_points)
    real*8, intent(in) :: grid(n_grid)
    real*8, intent(out) :: filtered(n_grid)
    logical, intent(out) :: valid(n_grid)

    integer :: i, j, n_retained
    real*8 :: time_min, time_max, full_time_max
    real*8 :: lower_limit, upper_limit, nearest
    real*8 :: target, delta_time, weight, numerator, denominator

    filtered = 0.d0
    valid = .false.
    n_retained = 0
    time_min = huge(1.d0)
    time_max = -huge(1.d0)
    full_time_max = -huge(1.d0)

    do i = 1, n_data
      if (time(i) >= analysis_start .and. time(i) <= retained_end) then
        full_time_max = max(full_time_max,time(i))
      end if
      if (time(i) < analysis_start .or. time(i) > analysis_end) cycle
      n_retained = n_retained + 1
      time_min = min(time_min, time(i))
      time_max = max(time_max, time(i))
    end do

    if (n_retained == 0) return

    lower_limit = time_min
    upper_limit = time_max

    if (time_min - analysis_start <= 2.d0*sigma) then
      lower_limit = analysis_start
    end if
    if (analysis_end - time_max <= 2.d0*sigma) then
      upper_limit = analysis_end
    end if

    do j = 1, n_grid
      target = grid(j)
      if (target <= analysis_end) then
        if (target < lower_limit .or. target > upper_limit) cycle
      else
        if (target > full_time_max) cycle
      end if

      numerator = 0.d0
      denominator = 0.d0
      nearest = huge(1.d0)

      do i = 1, n_data
        if (time(i) < analysis_start .or. time(i) > retained_end) cycle
        if (target <= analysis_end .and. time(i) > analysis_end) cycle

        delta_time = time(i) - target
        nearest = min(nearest,abs(delta_time))
        weight = exp(-0.5d0*(delta_time/sigma)**2)

        numerator = numerator + weight*zscore(i)
        denominator = denominator + weight
      end do

      ! Gaussian weighted mean at this age.
      if (denominator > 0.d0) then
        filtered(j) = numerator/denominator
        valid(j) = .true.
      end if

    end do
  end subroutine gaussian_filter

!-------------------------------------------------------------------------------
  ! Re-standardize each filtered curve over its valid 0--11 ka BP values.
  ! Use the sample standard deviation (N-1); preserve the sign of the input proxy.
  subroutine standardize_filtered(filtered, valid, standardized)
    implicit none

    real*8, intent(in) :: filtered(n_grid,n_proxy)
    logical, intent(in) :: valid(n_grid,n_proxy)
    real*8, intent(out) :: standardized(n_grid,n_proxy)

    integer :: i, j, n_valid
    real*8 :: mean_value, standard_deviation

    standardized = 0.d0

    do i = 1, n_proxy
      n_valid = count(valid(1:n_paper_grid,i))
      if (n_valid < 2) then
        write(*,'(A,I0,A)') 'ERROR: proxy ', i, &
                            ' has fewer than two valid filtered values.'
        stop 1
      end if

      mean_value = sum(filtered(1:n_paper_grid,i), &
                       mask=valid(1:n_paper_grid,i))/dble(n_valid)
      standard_deviation = sqrt( &
        sum((filtered(1:n_paper_grid,i)-mean_value)**2, &
            mask=valid(1:n_paper_grid,i)) / &
        dble(n_valid-1))

      if (standard_deviation <= tiny(1.d0)) then
        write(*,'(A,I0,A)') 'ERROR: proxy ', i, &
                            ' has zero variance after filtering.'
        stop 1
      end if

      do j = 1, n_grid
        if (valid(j,i)) then
          standardized(j,i) = &
            (filtered(j,i)-mean_value)/standard_deviation
        end if
      end do
    end do
  end subroutine standardize_filtered

!-------------------------------------------------------------------------------
  ! Write one time/value table per filtered, re-standardized proxy.
  ! Use three decimals for ages and six for values, matching the analysis inputs.
  subroutine write_individual_outputs(output_directory, grid, filtered, valid)
    implicit none

    character(len=*), intent(in) :: output_directory
    real*8, intent(in) :: grid(n_grid), filtered(n_grid,n_proxy)
    logical, intent(in) :: valid(n_grid,n_proxy)

    character(len=1024) :: output_path
    integer :: i, j, unit_out, io_status

    do i = 1, n_proxy
      output_path = trim(output_directory)//'/'//trim(output_names(i))
      open(newunit=unit_out,file=trim(output_path),status='replace', &
           action='write',iostat=io_status)
      if (io_status /= 0) then
        write(*,'(A)') 'ERROR: cannot create '//trim(output_path)
        stop 1
      end if
      write(unit_out,'(A)') '# Time[ka_BP1950] '//trim(proxy_identifier(i))
      write(unit_out,'(a)') &
        '# Column 1 = Age [ka BP1950; present = 1950 CE].', &
        '# Column 2 = Filtered, re-standardized trend Z score [dimensionless].'
      write(unit_out,'(a)') '# Proxy '//trim(proxy_identifier(i))//' = '//trim(relative_path(i))
      do j = 1, n_grid
        if (.not. valid(j,i)) cycle
        write(unit_out,'(F7.3,1X,F12.6)') grid(j),filtered(j,i)
      end do
      close(unit_out)
      write(*,'(A)') 'Created '//trim(output_path)
    end do
  end subroutine write_individual_outputs

!-------------------------------------------------------------------------------
  ! Identify each proxy by its configured output filename prefix.
  function proxy_identifier(proxy_index) result(identifier)
    integer, intent(in) :: proxy_index
    character(len=128) :: identifier
    integer :: separator

    identifier=output_names(proxy_index)
    separator=index(identifier,'_')
    if (separator>1) identifier=identifier(:separator-1)
  end function proxy_identifier

!-------------------------------------------------------------------------------
  ! Write the combined filtered table with column labels and NaN for missing values.
  subroutine write_output(filename, grid, filtered, valid)
    implicit none

    character(len=*), intent(in) :: filename
    real*8, intent(in) :: grid(n_grid)
    real*8, intent(in) :: filtered(n_grid,n_proxy)
    logical, intent(in) :: valid(n_grid,n_proxy)

    integer :: unit_out, io_status, i, j

    unit_out = 20
    open(unit=unit_out, file=trim(filename), status='replace', action='write', &
         iostat=io_status)
    if (io_status /= 0) then
      write(*,'(A)') 'ERROR: cannot create '//trim(filename)
      stop 1
    end if
    write(unit_out,'(A)',advance='no') '# Time[ka_BP1950]'
    do i = 1, n_proxy
      write(unit_out,'(1X,A)',advance='no') trim(proxy_identifier(i))
    end do
    write(unit_out,*)
    write(unit_out,'(a)') &
      '# Column 1 = Age [ka BP1950; present = 1950 CE].'
    do i = 1, n_proxy
      write(unit_out,'(a,i0,3a)') '# Column ',i+1,' = ',trim(proxy_identifier(i)), &
        ': filtered input Z score, before re-standardization.'
      write(unit_out,'(a)') '# Proxy '//trim(proxy_identifier(i))//' = '//trim(relative_path(i))
    end do
    do j = 1, n_grid
      write(unit_out,'(F7.3)',advance='no') grid(j)
      do i = 1, n_proxy
        if (valid(j,i)) then
          write(unit_out,'(1X,F12.6)',advance='no') filtered(j,i)
        else
          write(unit_out,'(1X,A12)',advance='no') 'NaN'
        end if
      end do
      write(unit_out,*)
    end do

    close(unit_out)
  end subroutine write_output

!-------------------------------------------------------------------------------
  ! Read the next plain-text control record, skipping blank lines and comments.
  subroutine control_line(unit,record)
    integer, intent(in) :: unit
    character(len=*), intent(out) :: record
    integer :: status

    do
      read(unit,'(a)',iostat=status) record
      if (status/=0) error stop 'Incomplete run.dat.'
      record=adjustl(record)
      if (len_trim(record)==0) cycle
      if (record(1:1)=='#'.or.record(1:1)=='!') cycle
      exit
    end do
  end subroutine control_line

!-------------------------------------------------------------------------------
  ! Relative input/output directories are interpreted from the run.dat directory.
  function resolve_path(path) result(full_path)
    character(len=*), intent(in) :: path
    character(len=1024) :: full_path

    if (path(1:1)=='/') then
      full_path=path
    else
      full_path=trim(control_directory)//'/'//trim(path)
    end if
  end function resolve_path

!-------------------------------------------------------------------------------
  subroutine ensure_output_directory(directory)
    character(len=*), intent(in) :: directory
    character(len=2048) :: command
    integer :: exit_status,command_status
    logical :: exists

    inquire(file=trim(directory),exist=exists)
    if (exists) return
    if (index(directory,"'")>0) &
      error stop 'ERROR: apostrophes are not supported in the output directory path.'
    command="mkdir -p '"//trim(directory)//"'"
    exit_status=0
    command_status=0
    call execute_command_line(trim(command),wait=.true.,exitstat=exit_status, &
      cmdstat=command_status)
    if (command_status/=0 .or. exit_status/=0) &
      error stop 'ERROR: could not create the output directory.'
  end subroutine ensure_output_directory

end program filter_ssa_proxies
