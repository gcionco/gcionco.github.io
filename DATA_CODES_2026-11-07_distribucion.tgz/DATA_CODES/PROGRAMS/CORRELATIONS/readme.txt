MOVING PEARSON AND SPEARMAN CORRELATIONS
----------------------------------------

Edit run.dat to set  windows, bootstrap resamples, block length, seed, age interval,
grid step, quantiles, paths, case files and sign multipliers.

BEFORE RUNNING
Requires the filtered P*.dat files produced by FILTERING and the supplied forcings F*.dat.
Copy them manually to input/. If these files are already present, run directly.

INPUT
input/P*.dat: copies from ../FILTERING/output/proxies/.
input/F*.dat: copies from ../../DATA/FORCINGS/.
Columns: age [ka BP1950], Z score. Signs are applied from run.dat data.

OUTPUT
Each output table includes # Column N = ... lines defining its columns.
output/<case filename in run.dat>: every window and related forcing.
Columns:
  1 center age [ka BP1950]; 2 window N; 3 local forcing index;
  4 Pearson r; 5/6 lower/upper pointwise bootstrap bounds for r;
  7 Spearman rho; 8/9 lower/upper pointwise bootstrap bounds for rho;
  10/11 valid Pearson/Spearman bootstrap counts;
  12/13 zero-exclusion flags for Pearson/Spearman (1 excludes, 0 includes zero);
  14 fraction of finite bootstrap r values with the point coefficient's sign.
The default bounds use 2.5/97.5 percentiles.
Forcing indices follow the case order in run.dat. Case seed = base seed + case - 1.

FIGURES
From figures/:
  ./fig07_moving_pearson.gp      FIG7.pdf.
The GNUPLOT script reads the six correlation output files directly.
Their filenames are listed at its beginning; keep them consistent with run.dat.
