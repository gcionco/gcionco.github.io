! Moving Pearson/Spearman correlations with paired moving-block bootstrap.
! INPUT
!   run.dat: windows, resamples, block length, seed, age grid, percentiles and case files.
!   input/P*.dat: filtered proxy series copied from FILTERING/output/proxies/.
!   input/F*.dat: forcing curves copied from /DATA/FORCINGS/.
!   Each series has age [ka BP1950] and Z value in its first two columns.
! OUTPUT
!   output/<case output_file>: one row per window and related forcing.
!   Columns: center, N, forcing index, r, r bounds, rho, rho bounds, valid counts,
!   zero-exclusion flags and Pearson bootstrap same-sign fraction.
!
! AUTHOR: R. G: CIONCO, 2026

program correlaciones_ventanas_spearman

  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite, ieee_quiet_nan, &
                                           ieee_value
  implicit none

  double precision, parameter :: pi=4.d0 * DATAN(1.d0)

  integer :: WINDOW_POINTS    = 31
  integer :: NUMBER_RESAMPLES = 1999
  integer :: BLOCK_POINTS     = 10
  integer :: NUMBER_CASES
  integer*8 :: INITIAL_RANDOM_SEED = 20260724_8

  real*8 :: LOWER_PROBABILITY
  real*8 :: UPPER_PROBABILITY
  real*8 :: EXPECTED_TIME_STEP
  real*8, parameter :: TIME_TOLERANCE = 1.d-6
  real*8 :: ANALYSIS_START,ANALYSIS_END

  integer*8, save :: random_state = 20260724_8

  type :: case_inputs
    character(len=128) :: proxy_file,output_file
    integer :: nf
    real*8 :: proxy_sign
    character(len=128), allocatable :: forcing_files(:)
    real*8, allocatable :: forcing_signs(:)
  end type case_inputs
  type(case_inputs), allocatable :: cases(:)
  character(len=512), allocatable :: input_files(:),output_files(:)
  character(len=512) :: executable,root_directory,input_directory,output_directory
  character(len=4096) :: control_record
  integer :: case_index,command_status,config_unit,config_status,k,position

  ! Read all run choices from run.dat beside the executable.
  call get_command_argument(0,executable)
  position=scan(trim(executable),'/',back=.true.)
  root_directory='.'
  if (position>0) root_directory=executable(:position)
  open(newunit=config_unit,file=trim(root_directory)//'/run.dat',status='old', &
    action='read',iostat=config_status)
  if (config_status/=0) error stop 'Cannot open run.dat beside the executable.'
  call read_control_line(config_unit,control_record)
  read(control_record,*,iostat=config_status) WINDOW_POINTS,NUMBER_RESAMPLES,BLOCK_POINTS,INITIAL_RANDOM_SEED
  if (config_status/=0) error stop 'Invalid bootstrap/window parameters.'
  call read_control_line(config_unit,control_record)
  read(control_record,*,iostat=config_status) ANALYSIS_START,ANALYSIS_END,EXPECTED_TIME_STEP, &
    LOWER_PROBABILITY,UPPER_PROBABILITY
  if (config_status/=0) error stop 'Invalid grid/interval parameters.'
  if (ANALYSIS_END<=ANALYSIS_START.or.EXPECTED_TIME_STEP<=0.d0) error stop 'Invalid age grid.'
  if (LOWER_PROBABILITY<0.d0.or.UPPER_PROBABILITY>1.d0.or. &
    LOWER_PROBABILITY>=UPPER_PROBABILITY) error stop 'Invalid percentile probabilities.'
  if (NUMBER_RESAMPLES<2) error stop 'At least two bootstrap resamples are required.'
  if (BLOCK_POINTS<1.or.BLOCK_POINTS>WINDOW_POINTS) error stop 'Invalid moving-block length.'
  call read_control_line(config_unit,control_record)
  input_directory=local_path(trim(control_record))
  call read_control_line(config_unit,control_record)
  output_directory=local_path(trim(control_record))
  call read_control_line(config_unit,control_record)
  read(control_record,*,iostat=config_status) NUMBER_CASES
  if (config_status/=0.or.NUMBER_CASES<1) error stop 'Invalid number of cases.'
  allocate(cases(NUMBER_CASES),input_files(NUMBER_CASES),output_files(NUMBER_CASES))
  do case_index=1,NUMBER_CASES
    call read_control_line(config_unit,control_record)
    read(control_record,*,iostat=config_status) cases(case_index)%proxy_file,cases(case_index)%output_file, &
      cases(case_index)%nf,cases(case_index)%proxy_sign
    if (config_status/=0.or.cases(case_index)%nf<1) error stop 'Invalid case definition.'
    if (abs(abs(cases(case_index)%proxy_sign)-1.d0)>TIME_TOLERANCE) error stop 'Invalid proxy sign.'
    allocate(cases(case_index)%forcing_files(cases(case_index)%nf))
    allocate(cases(case_index)%forcing_signs(cases(case_index)%nf))
    do k=1,cases(case_index)%nf
      call read_control_line(config_unit,control_record)
      read(control_record,*,iostat=config_status) cases(case_index)%forcing_files(k), &
        cases(case_index)%forcing_signs(k)
      if (config_status/=0) error stop 'Invalid forcing definition.'
      if (abs(abs(cases(case_index)%forcing_signs(k))-1.d0)>TIME_TOLERANCE) error stop 'Invalid forcing sign.'
    end do
    input_files(case_index)=trim(input_directory)//'/'//trim(cases(case_index)%proxy_file)
    output_files(case_index)=trim(output_directory)//'/'//trim(cases(case_index)%output_file)
  end do
  close(config_unit)

  call ensure_output_directory(trim(output_directory))
  do case_index=1,NUMBER_CASES
    call analyze_one_file(case_index,trim(input_files(case_index)), &
                          trim(output_files(case_index)), &
                          INITIAL_RANDOM_SEED+int(case_index-1,8))
  end do

  write(*,'(a)') 'All input cases processed.'
  write(*,'(a)') 'Results written to output/.'

contains





  ! Apply the paper plotting signs in memory; never change the input files.
  ! Cases: BTV2/BTV3A: -P, F01 F02 F03 F04 -F05 F06;
  ! Al/Si and Fe: +P, F01 F02 F03 F07; Palm2: -P, -F08 F09 F10;
  ! Laguna Azul: -P, -F09 F11 -F10.
  subroutine apply_paper_sign_convention(case_number,proxy,forcing,n_rows, &
                                         n_forcings)

    integer, intent(in) :: case_number,n_rows,n_forcings
    real*8, intent(inout) :: proxy(n_rows),forcing(n_rows,n_forcings)

    integer :: j
    if (n_forcings/=cases(case_number)%nf) error stop 'Input forcing count differs from run.dat.'
    proxy=cases(case_number)%proxy_sign*proxy
    do j=1,n_forcings
      forcing(:,j)=cases(case_number)%forcing_signs(j)*forcing(:,j)
    end do

  end subroutine apply_paper_sign_convention




  ! For each complete moving window, calculate Pearson r and Spearman rho.
  ! Resample consecutive moving blocks jointly for P and all F columns.
  ! Recompute ranks in every resample, retaining average ranks for ties.
  ! Write every window, including coefficients whose pointwise interval includes zero.
  subroutine analyze_one_file(case_number,input_file,output_file,random_seed)

    character(len=*), intent(in) :: input_file,output_file
    integer, intent(in) :: case_number
    integer*8, intent(in) :: random_seed

    integer :: number_rows,number_forcings,number_columns
    integer :: row,forcing_index,resample,window_start
    integer :: source_row,input_status,output_unit
    integer :: valid_pearson,valid_spearman
    integer :: flag_pearson,flag_spearman

    real*8, allocatable :: time(:)
    real*8, allocatable :: proxy(:)
    real*8, allocatable :: forcing(:,:)
    real*8, allocatable :: proxy_resampled(:)
    real*8, allocatable :: forcing_resampled(:,:)
    real*8, allocatable :: proxy_ranks(:)
    real*8, allocatable :: forcing_ranks(:)
    real*8, allocatable :: pearson_resampled(:,:)
    real*8, allocatable :: spearman_resampled(:,:)
    integer, allocatable :: resampled_indices(:)

    real*8 :: window_center
    real*8 :: pearson_value,spearman_value
    real*8 :: pearson_lower,pearson_upper
    real*8 :: spearman_lower,spearman_upper
    real*8 :: pearson_sign_stability

    call read_separate_inputs(case_number,time,proxy,forcing)
    number_rows=size(time)
    number_forcings=size(forcing,2)
    number_columns=number_forcings+2

    if (number_rows < WINDOW_POINTS) then
      error stop 'ERROR: an input has fewer values than the window length.'
    end if

    if (number_forcings < 1) then
      error stop 'ERROR: an input contains no forcing columns.'
    end if

    allocate(proxy_resampled(WINDOW_POINTS))
    allocate(forcing_resampled(WINDOW_POINTS,number_forcings))
    allocate(proxy_ranks(WINDOW_POINTS))
    allocate(forcing_ranks(WINDOW_POINTS))
    allocate(pearson_resampled(NUMBER_RESAMPLES,number_forcings))
    allocate(spearman_resampled(NUMBER_RESAMPLES,number_forcings))
    allocate(resampled_indices(WINDOW_POINTS))

    call validate_input_data(time,proxy,forcing,number_rows,number_forcings)
    call apply_paper_sign_convention(case_number,proxy,forcing,number_rows, &
                                     number_forcings)
    call set_random_seed(random_seed)

    open(newunit=output_unit,file=output_file,status='replace', &
         action='write',iostat=input_status)

    if (input_status /= 0) then
      write(*,'(a)') 'ERROR: cannot create output file: '// &
                     trim(output_file)
      error stop 1
    end if

    write(output_unit,'(a)') &
      '# Moving Pearson and Spearman correlations with paired moving-block bootstrap.', &
      '# Column 1 = Window center age [ka BP1950; present = 1950 CE].', &
      '# Column 2 = Number of paired observations in the window.', &
      '# Column 3 = Local forcing index, identified below in run.dat order.', &
      '# Column 4 = Pearson correlation coefficient r [dimensionless].', &
      '# Column 5 = Lower bootstrap percentile bound for r.', &
      '# Column 6 = Upper bootstrap percentile bound for r.', &
      '# Column 7 = Spearman rank correlation coefficient rho [dimensionless].', &
      '# Column 8 = Lower bootstrap percentile bound for rho.', &
      '# Column 9 = Upper bootstrap percentile bound for rho.', &
      '# Column 10 = Number of valid Pearson bootstrap coefficients.', &
      '# Column 11 = Number of valid Spearman bootstrap coefficients.', &
      '# Column 12 = Pearson interval excludes zero: 1 = yes; 0 = otherwise.', &
      '# Column 13 = Spearman interval excludes zero: 1 = yes; 0 = otherwise.', &
      '# Column 14 = Fraction of valid bootstrap r values with the observed r sign.', &
      '# Percentile probabilities are specified in run.dat.'
    write(output_unit,'(a)') '# Proxy file = '//trim(cases(case_number)%proxy_file)
    write(output_unit,'(a,f4.1)') '# Proxy sign multiplier = ',cases(case_number)%proxy_sign
    do forcing_index=1,number_forcings
      write(output_unit,'(a,i0,3a,f4.1)') '# Forcing ',forcing_index,' = ', &
        trim(cases(case_number)%forcing_files(forcing_index)), &
        '; sign multiplier = ',cases(case_number)%forcing_signs(forcing_index)
    end do

    do window_start=1,number_rows-WINDOW_POINTS+1

      window_center=0.5d0*(time(window_start)+ &
                           time(window_start+WINDOW_POINTS-1))

      do resample=1,NUMBER_RESAMPLES

        call generate_block_indices(WINDOW_POINTS,BLOCK_POINTS, &
                                    resampled_indices)

        do row=1,WINDOW_POINTS
          source_row=window_start+resampled_indices(row)-1
          proxy_resampled(row)=proxy(source_row)
          forcing_resampled(row,:)=forcing(source_row,:)
        end do

        call calculate_ranks(proxy_resampled,WINDOW_POINTS,proxy_ranks)

        do forcing_index=1,number_forcings

          pearson_resampled(resample,forcing_index)=pearson_correlation( &
            proxy_resampled,forcing_resampled(:,forcing_index),WINDOW_POINTS)

          call calculate_ranks(forcing_resampled(:,forcing_index), &
                               WINDOW_POINTS,forcing_ranks)

          spearman_resampled(resample,forcing_index)=pearson_correlation( &
            proxy_ranks,forcing_ranks,WINDOW_POINTS)

        end do
      end do

      call calculate_ranks( &
        proxy(window_start:window_start+WINDOW_POINTS-1), &
        WINDOW_POINTS,proxy_ranks)

      do forcing_index=1,number_forcings

        pearson_value=pearson_correlation( &
          proxy(window_start:window_start+WINDOW_POINTS-1), &
          forcing(window_start:window_start+WINDOW_POINTS-1,forcing_index), &
          WINDOW_POINTS)

        call calculate_ranks( &
          forcing(window_start:window_start+WINDOW_POINTS-1,forcing_index), &
          WINDOW_POINTS,forcing_ranks)

        spearman_value=pearson_correlation(proxy_ranks,forcing_ranks, &
                                           WINDOW_POINTS)

        call empirical_interval(pearson_resampled(:,forcing_index), &
          NUMBER_RESAMPLES,LOWER_PROBABILITY,UPPER_PROBABILITY, &
          pearson_lower,pearson_upper,valid_pearson)

        call empirical_interval(spearman_resampled(:,forcing_index), &
          NUMBER_RESAMPLES,LOWER_PROBABILITY,UPPER_PROBABILITY, &
          spearman_lower,spearman_upper,valid_spearman)

        flag_pearson=interval_excludes_zero(pearson_lower,pearson_upper)
        flag_spearman=interval_excludes_zero(spearman_lower,spearman_upper)
        pearson_sign_stability=sign_stability(pearson_value, &
          pearson_resampled(:,forcing_index),NUMBER_RESAMPLES)

        write(output_unit, &
          '(f9.3,1x,i4,1x,i4,6(1x,es17.9),2(1x,i5),2(1x,i1),1x,f10.6)') &
          window_center,WINDOW_POINTS,forcing_index, &
          pearson_value,pearson_lower,pearson_upper, &
          spearman_value,spearman_lower,spearman_upper, &
          valid_pearson,valid_spearman,flag_pearson,flag_spearman, &
          pearson_sign_stability

      end do
    end do

    close(output_unit)

    write(*,'(a)') 'Proxy file: '//trim(input_file)
    write(*,'(a,i0)') '  Number of time values: ',number_rows
    write(*,'(a,i0)') '  Number of forcing curves: ',number_forcings
    write(*,'(a)') '  Output: '//trim(output_file)

    deallocate(time,proxy,forcing)
    deallocate(proxy_resampled,forcing_resampled)
    deallocate(proxy_ranks,forcing_ranks)
    deallocate(pearson_resampled,spearman_resampled)
    deallocate(resampled_indices)

  end subroutine analyze_one_file

!----------------------------------------------------------------------------------
! Count usable 0--11 ka BP records and forcing columns before allocating arrays.
! Validate the proxy and forcing arrays after reading the input files.
! Require finite values and strictly increasing ages on the configured regular grid.


  subroutine validate_input_data(time_values,proxy_values,forcing_values, &
                                 n_rows,n_forcings)

    integer, intent(in) :: n_rows,n_forcings
    real*8, intent(in) :: time_values(n_rows),proxy_values(n_rows)
    real*8, intent(in) :: forcing_values(n_rows,n_forcings)
    integer :: i

    if (.not.all(ieee_is_finite(time_values))) then
      error stop 'ERROR: time column contains NaN or infinity.'
    end if

    if (.not.all(ieee_is_finite(proxy_values))) then
      error stop 'ERROR: proxy column contains NaN or infinity.'
    end if

    if (.not.all(ieee_is_finite(forcing_values))) then
      error stop 'ERROR: a forcing column contains NaN or infinity.'
    end if

    do i=2,n_rows
      if (time_values(i) <= time_values(i-1)) then
        error stop 'ERROR: BP ages must increase toward the past.'
      end if

      if (abs((time_values(i)-time_values(i-1))-EXPECTED_TIME_STEP) > &
          TIME_TOLERANCE) then
        write(*,'(a,i0,a,i0,a,es14.6)') &
          'ERROR: expected a 0.1 ka step between rows ',i-1, &
          ' y ',i,': ',time_values(i)-time_values(i-1)
        error stop 1
      end if
    end do

  end subroutine validate_input_data


  ! Recognize non-empty data records, ignoring # and ! comment lines.
  logical function is_data_line(line)

    character(len=*), intent(in) :: line
    integer :: i

    is_data_line=.false.

    do i=1,len_trim(line)
      if (line(i:i) /= ' ' .and. line(i:i) /= achar(9)) then
        if (line(i:i) /= '#' .and. line(i:i) /= '!') is_data_line=.true.
        return
      end if
    end do

  end function is_data_line


  ! Count whitespace-separated input fields without modifying their contents.
  integer function count_fields(line)

    character(len=*), intent(in) :: line
    integer :: i
    logical :: inside_field

    count_fields=0
    inside_field=.false.

    do i=1,len_trim(line)

      if (line(i:i) == '#' .or. line(i:i) == '!') exit

      if (line(i:i) == ' ' .or. line(i:i) == achar(9)) then
        inside_field=.false.
      else
        if (.not.inside_field) count_fields=count_fields+1
        inside_field=.true.
      end if

    end do

  end function count_fields


  ! Initialize the correlation generator independently for each case using base seed +
  ! case - 1.
  subroutine set_random_seed(initial_seed)

    integer*8, intent(in) :: initial_seed
    integer*8, parameter :: MODULUS = 2147483647_8

    random_state=modulo(initial_seed,MODULUS-1_8)+1_8

  end subroutine set_random_seed


  ! Advance the original integer random-number generator and return its uniform variate.
  real*8 function random_uniform()

    integer*8, parameter :: MULTIPLIER = 16807_8
    integer*8, parameter :: MODULUS = 2147483647_8

    random_state=mod(MULTIPLIER*random_state,MODULUS)
    random_uniform=dble(random_state)/dble(MODULUS)

  end function random_uniform


  ! Convert a uniform draw into an inclusive integer index.
  integer function random_integer(first,last)

    integer, intent(in) :: first,last

    random_integer=first+int(random_uniform()*dble(last-first+1))
    if (random_integer > last) random_integer=last

  end function random_integer


  ! Sample starting positions of overlapping moving blocks with replacement.
  ! Concatenate blocks and truncate the last block to the original window length.
  subroutine generate_block_indices(number_values,block_length,indices)

    integer, intent(in) :: number_values,block_length
    integer, intent(out) :: indices(number_values)

    integer :: position,inside_block,block_start

    position=0

    do while(position < number_values)

      block_start=random_integer(1,number_values-block_length+1)

      do inside_block=0,block_length-1
        if (position >= number_values) exit
        position=position+1
        indices(position)=block_start+inside_block
      end do

    end do

  end subroutine generate_block_indices


  ! Calculate the centered Pearson coefficient; return NaN for a degenerate variance.
  real*8 function pearson_correlation(x,y,number_values)

    integer, intent(in) :: number_values
    real*8, intent(in) :: x(number_values),y(number_values)

    real*8 :: mean_x,mean_y
    real*8 :: sum_xx,sum_yy,sum_xy
    real*8 :: scale_x,scale_y,tolerance_x,tolerance_y

    mean_x=sum(x)/dble(number_values)
    mean_y=sum(y)/dble(number_values)

    sum_xx=sum((x-mean_x)**2)
    sum_yy=sum((y-mean_y)**2)
    sum_xy=sum((x-mean_x)*(y-mean_y))

    scale_x=max(1.d0,maxval(abs(x)))
    scale_y=max(1.d0,maxval(abs(y)))

    tolerance_x=epsilon(1.d0)*dble(number_values)*scale_x*scale_x
    tolerance_y=epsilon(1.d0)*dble(number_values)*scale_y*scale_y

    if (sum_xx <= tolerance_x .or. sum_yy <= tolerance_y) then
      pearson_correlation=ieee_value(0.d0,ieee_quiet_nan)
    else
      pearson_correlation=sum_xy/sqrt(sum_xx*sum_yy)
      pearson_correlation=max(-1.d0,min(1.d0,pearson_correlation))
    end if

  end function pearson_correlation


  ! Assign ascending ranks, using the average rank for tied values.
  subroutine calculate_ranks(values,number_values,ranks)

    integer, intent(in) :: number_values
    real*8, intent(in) :: values(number_values)
    real*8, intent(out) :: ranks(number_values)

    integer :: order(number_values)
    integer :: i,j,key_index,first_equal,last_equal
    real*8 :: average_rank,tie_tolerance

    do i=1,number_values
      order(i)=i
    end do

    do i=2,number_values
      key_index=order(i)
      j=i-1

      do while(j >= 1)
        if (values(order(j)) <= values(key_index)) exit
        order(j+1)=order(j)
        j=j-1
      end do

      order(j+1)=key_index
    end do

    first_equal=1

    do while(first_equal <= number_values)

      last_equal=first_equal

      do while(last_equal < number_values)
        tie_tolerance=epsilon(1.d0)*max(1.d0, &
          abs(values(order(last_equal+1))),abs(values(order(first_equal))))
        if (abs(values(order(last_equal+1))-values(order(first_equal))) > &
            tie_tolerance) exit
        last_equal=last_equal+1
      end do

      average_rank=0.5d0*dble(first_equal+last_equal)

      do i=first_equal,last_equal
        ranks(order(i))=average_rank
      end do

      first_equal=last_equal+1
    end do

  end subroutine calculate_ranks


  ! Discard non-finite bootstrap coefficients, sort the valid values and calculate bounds.
  subroutine empirical_interval(values,number_values,lower_probability, &
                                upper_probability,lower_limit,upper_limit, &
                                number_valid)

    integer, intent(in) :: number_values
    real*8, intent(in) :: values(number_values)
    real*8, intent(in) :: lower_probability,upper_probability
    real*8, intent(out) :: lower_limit,upper_limit
    integer, intent(out) :: number_valid

    real*8, allocatable :: finite_values(:)
    integer :: i

    number_valid=count(ieee_is_finite(values))

    if (number_valid < 2) then
      lower_limit=ieee_value(0.d0,ieee_quiet_nan)
      upper_limit=ieee_value(0.d0,ieee_quiet_nan)
      return
    end if

    allocate(finite_values(number_valid))

    number_valid=0
    do i=1,number_values
      if (ieee_is_finite(values(i))) then
        number_valid=number_valid+1
        finite_values(number_valid)=values(i)
      end if
    end do

    call quicksort(finite_values,1,number_valid)

    lower_limit=ordered_percentile(finite_values,number_valid, &
                                   lower_probability)
    upper_limit=ordered_percentile(finite_values,number_valid, &
                                   upper_probability)

    deallocate(finite_values)

  end subroutine empirical_interval


  ! Return the fraction of valid bootstrap Pearson coefficients with the observed sign.
  real*8 function sign_stability(observed_value,bootstrap_values,number_values)

    integer, intent(in) :: number_values
    real*8, intent(in) :: observed_value,bootstrap_values(number_values)

    integer :: i,number_valid,number_same_sign

    if (.not.ieee_is_finite(observed_value)) then
      sign_stability=ieee_value(0.d0,ieee_quiet_nan)
      return
    end if

    number_valid=0
    number_same_sign=0

    do i=1,number_values
      if (.not.ieee_is_finite(bootstrap_values(i))) cycle
      number_valid=number_valid+1

      if (observed_value > 0.d0 .and. bootstrap_values(i) > 0.d0) then
        number_same_sign=number_same_sign+1
      else if (observed_value < 0.d0 .and. bootstrap_values(i) < 0.d0) then
        number_same_sign=number_same_sign+1
      else if (abs(observed_value) <= epsilon(1.d0) .and. &
               abs(bootstrap_values(i)) <= epsilon(1.d0)) then
        number_same_sign=number_same_sign+1
      end if
    end do

    if (number_valid == 0) then
      sign_stability=ieee_value(0.d0,ieee_quiet_nan)
    else
      sign_stability=dble(number_same_sign)/dble(number_valid)
    end if

  end function sign_stability


  ! Interpolate the requested percentile within an already sorted valid sample.
  real*8 function ordered_percentile(ordered_values,number_values,probability)

    integer, intent(in) :: number_values
    real*8, intent(in) :: ordered_values(number_values),probability

    real*8 :: position,fraction
    integer :: lower_index

    position=1.d0+probability*dble(number_values-1)
    lower_index=int(position)
    fraction=position-dble(lower_index)

    if (lower_index >= number_values) then
      ordered_percentile=ordered_values(number_values)
    else
      ordered_percentile=(1.d0-fraction)*ordered_values(lower_index)+ &
                         fraction*ordered_values(lower_index+1)
    end if

  end function ordered_percentile


  ! Sort coefficient values in place for empirical percentile calculations.
  recursive subroutine quicksort(values,left,right)

    real*8, intent(inout) :: values(:)
    integer, intent(in) :: left,right

    integer :: i,j
    real*8 :: pivot,temporary

    if (left >= right) return

    i=left
    j=right
    pivot=values((left+right)/2)

    do
      do while(i <= right)
        if (values(i) >= pivot) exit
        i=i+1
      end do

      do while(j >= left)
        if (values(j) <= pivot) exit
        j=j-1
      end do

      if (i > j) exit

      temporary=values(i)
      values(i)=values(j)
      values(j)=temporary
      i=i+1
      j=j-1
    end do

    if (left < j) call quicksort(values,left,j)
    if (i < right) call quicksort(values,i,right)

  end subroutine quicksort


  ! Set a pointwise significance flag only when the complete interval excludes zero.
  integer function interval_excludes_zero(lower_limit,upper_limit)

    real*8, intent(in) :: lower_limit,upper_limit

    if (.not.ieee_is_finite(lower_limit) .or. &
        .not.ieee_is_finite(upper_limit)) then
      interval_excludes_zero=0
    else if (lower_limit > 0.d0 .or. upper_limit < 0.d0) then
      interval_excludes_zero=1
    else
      interval_excludes_zero=0
    end if

  end function interval_excludes_zero


  ! Read an explicit local copy of a two-column series; select the configured ages.
  ! No resampling, smoothing or standardization is performed here.
  subroutine read_curve(file_name,t,v)
    character(len=*), intent(in) :: file_name
    real*8, allocatable, intent(out) :: t(:),v(:)
    character(len=4096) :: line
    real*8 :: age,value
    integer :: unit,status,n,i,pass
    n=0
    do pass=1,2
      open(newunit=unit,file=file_name,status='old',action='read',iostat=status)
      if (status/=0) then
        write(*,'(2a)') 'Cannot open local input: ',trim(file_name)
        error stop 1
      end if
      i=0
      do
        read(unit,'(a)',iostat=status) line
        if (status<0) exit
        if (status/=0) error stop 'Error reading input series.'
        line=adjustl(line)
        if (len_trim(line)==0) cycle
        if (line(1:1)=='#'.or.line(1:1)=='!') cycle
        read(line,*,iostat=status) age
        if (status/=0) error stop 'Invalid age in input series.'
        if (age<ANALYSIS_START-TIME_TOLERANCE.or.age>ANALYSIS_END+TIME_TOLERANCE) cycle
        read(line,*,iostat=status) age,value
        if (status/=0) error stop 'Invalid input value.'
        i=i+1
        if (pass==2) then
          if (i>n) error stop 'Input changed while reading.'
          t(i)=age; v(i)=value
        end if
      end do
      close(unit)
      if (pass==1) then
        n=i
        if (n<1) error stop 'No input values in the configured interval.'
        allocate(t(n),v(n))
      else
        if (i/=n) error stop 'Input changed while reading.'
      end if
    end do
  end subroutine read_curve

!---------------------------------------------------------------------------------
  ! Assemble P and its related F columns in memory using the names in run.dat.
  ! Every input is a local file; the program never copies data from another stage.
  subroutine read_separate_inputs(c,t,p,f)
    integer, intent(in) :: c
    real*8, allocatable, intent(out) :: t(:),p(:),f(:,:)
    real*8, allocatable :: tf(:),vf(:)
    integer :: j,n
    call read_curve(trim(input_directory)//'/'//trim(cases(c)%proxy_file),t,p)
    n=size(t)
    allocate(f(n,cases(c)%nf))
    do j=1,cases(c)%nf
      call read_curve(trim(input_directory)//'/'//trim(cases(c)%forcing_files(j)),tf,vf)
      if (size(tf)/=n) error stop 'Proxy and forcing have different row counts.'
      if (any(abs(tf-t)>TIME_TOLERANCE)) error stop 'Proxy and forcing age grids differ.'
      f(:,j)=vf
      deallocate(tf,vf)
    end do
  end subroutine read_separate_inputs

!-------------------------------------------------------------------------------------
  subroutine read_control_line(unit,line)
    integer, intent(in) :: unit
    character(len=*), intent(out) :: line
    integer :: status
    do
      read(unit,'(a)',iostat=status) line
      if (status/=0) error stop 'Incomplete run.dat.'
      line=adjustl(line)
      if (len_trim(line)==0) cycle
      if (line(1:1)=='#'.or.line(1:1)=='!') cycle
      exit
    end do
  end subroutine read_control_line

!-------------------------------------------------
  function local_path(path) result(full_path)
    character(len=*), intent(in) :: path
    character(len=512) :: full_path
    if (path(1:1)=='/') then
      full_path=path
    else
      full_path=trim(root_directory)//'/'//trim(path)
    end if
  end function local_path

  subroutine ensure_output_directory(directory)
    character(len=*), intent(in) :: directory
    character(len=2048) :: command
    integer :: exit_status,command_status
    logical :: exists

    inquire(file=trim(directory),exist=exists)
    if (exists) return
    if (index(directory,"'")>0) &
      error stop 'ERROR: apostrophes are not supported in the output directory path.'
    command="mkdir -p '"//trim(directory)//"'"
    exit_status=0
    command_status=0
    call execute_command_line(trim(command),wait=.true.,exitstat=exit_status, &
      cmdstat=command_status)
    if (command_status/=0 .or. exit_status/=0) &
      error stop 'ERROR: could not create the output directory.'
  end subroutine ensure_output_directory

end program correlaciones_ventanas_spearman
