#!/usr/bin/gnuplot
# Moving Pearson correlation figure.
# INPUT
#   ../run.dat identifies ../output/<case correlation file>.
#   Columns: center=1, forcing index=3, r=4, zero-exclusion flag=12.
# OUTPUT
#   FIG7.pdf.

if (exists("ARG0")) {
    plot_directory = ""
    do for [path_position = strlen(ARG0):1:-1] {
        if (ARG0[path_position:path_position] eq "/" && strlen(plot_directory) == 0) {
            plot_directory = ARG0[1:path_position]
        }
    }
    if (strlen(plot_directory) > 0) {
        cd plot_directory
    }
}
# Paper Figure 7: pointwise-significant moving Pearson correlations.
# All numerical windows remain available in the results tables.
reset
set encoding utf8
set datafile commentschars "#"
set decimalsign locale "C"

# These filenames match the outputs configured in ../run.dat.
result_directory = "../output"
array case_outputs[6]
case_outputs[1] = "BTV2_Cruz_correlaciones.txt"
case_outputs[2] = "BTV3A_Wang_correlaciones.txt"
case_outputs[3] = "GeoB_AlSi_correlaciones.txt"
case_outputs[4] = "GeoB_Fe_correlaciones.txt"
case_outputs[5] = "Palm2_CaCO3_correlaciones.txt"
case_outputs[6] = "LagunaAzul_Nothofagus_correlaciones.txt"
case_file(k) = sprintf("%s/%s",result_directory,case_outputs[k])

set terminal pdfcairo enhanced color font "Nimbus Roman,24" size 21cm,24.7cm
set output "FIG7.pdf"

set border linewidth 0.8
set tics in nomirror font "Nimbus Roman,24"
set key font "Nimbus Roman,24"
set title font "Nimbus Roman,26"
set title offset 0,-0.8
set xlabel font "Nimbus Roman,32"
set ylabel font "Nimbus Roman,32"
set xtics 2
set mxtics 2
set ytics 0.5
set mytics 2
set xrange [0:11]
set yrange [-1:1]
set grid ytics lc rgb "light-gray" lw 0.5
set xzeroaxis dt 2 lw 1.0 lc rgb "gray30"
set style textbox 1 opaque margins 0.5,0.5 border lc rgb "gray10" lw 0.8 fillcolor rgb "white"


set multiplot layout 3,2 rowsfirst margins 0.12,0.98,0.08,0.95 spacing 0.08,0.08

data=case_file(1)
n_forcing=6
set title "-BTV2: -{/Symbol d}^{18}O"
unset ylabel
unset xlabel
set label 1 "(a)" right at graph 0.97,0.93 front boxed bs 1 font "Nimbus Roman,24"
set key center center maxrows 6 maxcols 1 opaque samplen 0.9 spacing 1.1 font "Nimbus Roman,17.5"
plot \
 data every n_forcing::0 using 1:($12==1?$4:1/0) with linespoints pt 7 ps 0.30 lw 1.2 lc rgb "red" title "{/Symbol D}W_{(30°S,DJF)}", \
 data every n_forcing::1 using 1:($12==1?$4:1/0) with linespoints pt 5 ps 0.30 lw 1.2 lc rgb "orange" title "{/Symbol D}W_{(30°S,SON+DJF)}", \
 data every n_forcing::2 using 1:($12==1?$4:1/0) with linespoints pt 9 ps 0.30 lw 1.2 lc rgb "black" title "{/Symbol D}W_{(30°S,DJF+MAM)}", \
 data every n_forcing::3 using 1:($12==1?$4:1/0) with linespoints pt 11 ps 0.30 lw 1.2 lc rgb "blue" title "{/Symbol D}W_{(30°S,S+DJF+M)}", \
 data every n_forcing::4 using 1:($12==1?$4:1/0) with linespoints pt 13 ps 0.30 lw 1.2 lc rgb "magenta" title "-MIG_{(0°-30°S,DJF)}", \
 data every n_forcing::5 using 1:($12==1?$4:1/0) with linespoints pt 3 ps 0.30 lw 1.2 lc rgb "gray" title "MIG_{(30°S-30°N,DJF)}", \
 data every n_forcing::0 using 1:($12==1?$4:1/0) with linespoints pt 7 ps 0.30 lw 1.2 lc rgb "red" notitle

data=case_file(2)
n_forcing=6
set title "-BTV3A: -{/Symbol d}^{18}O"
unset ylabel
unset xlabel
set label 1 "(b)" right at graph 0.97,0.93 front boxed bs 1 font "Nimbus Roman,24"
set key center center maxrows 6 maxcols 1 opaque samplen 0.9 spacing 1.1 font "Nimbus Roman,17.5"
plot \
 data every n_forcing::0 using 1:($12==1?$4:1/0) with linespoints pt 7 ps 0.30 lw 1.2 lc rgb "red" title "{/Symbol D}W_{(30°S,DJF)}", \
 data every n_forcing::1 using 1:($12==1?$4:1/0) with linespoints pt 5 ps 0.30 lw 1.2 lc rgb "orange" title "{/Symbol D}W_{(30°S,SON+DJF)}", \
 data every n_forcing::2 using 1:($12==1?$4:1/0) with linespoints pt 9 ps 0.30 lw 1.2 lc rgb "black" title "{/Symbol D}W_{(30°S,DJF+MAM)}", \
 data every n_forcing::3 using 1:($12==1?$4:1/0) with linespoints pt 11 ps 0.30 lw 1.2 lc rgb "blue" title "{/Symbol D}W_{(30°S,S+DJF+M)}", \
 data every n_forcing::4 using 1:($12==1?$4:1/0) with linespoints pt 13 ps 0.30 lw 1.2 lc rgb "magenta" title "-MIG_{(0°-30°S,DJF)}", \
 data every n_forcing::5 using 1:($12==1?$4:1/0) with linespoints pt 3 ps 0.30 lw 1.2 lc rgb "gray" title "MIG_{(30°S-30°N,DJF)}", \
 data every n_forcing::0 using 1:($12==1?$4:1/0) with linespoints pt 7 ps 0.30 lw 1.2 lc rgb "red" notitle

data=case_file(3)
n_forcing=4
set title "GeoB6211-2: Al/Si"
set ylabel "Pearson {/NimbusRoman-Italic r}" font "Nimbus Roman,32"
unset xlabel
set label 1 "(c)" right at graph 0.97,0.93 front boxed bs 1 font "Nimbus Roman,24"
set key center center maxrows 4 maxcols 1 opaque samplen 0.9 spacing 1.1 font "Nimbus Roman,17.5"
plot \
 data every n_forcing::0 using 1:($12==1?$4:1/0) with linespoints pt 7 ps 0.30 lw 1.2 lc rgb "red" title "{/Symbol D}W_{(30°S,DJF)}", \
 data every n_forcing::1 using 1:($12==1?$4:1/0) with linespoints pt 5 ps 0.30 lw 1.2 lc rgb "orange" title "{/Symbol D}W_{(30°S,SON+DJF)}", \
 data every n_forcing::2 using 1:($12==1?$4:1/0) with linespoints pt 9 ps 0.30 lw 1.2 lc rgb "black" title "{/Symbol D}W_{(30°S,DJF+MAM)}", \
 data every n_forcing::3 using 1:($12==1?$4:1/0) with linespoints pt 11 ps 0.30 lw 1.2 lc rgb "gray" title "MIG_{(30°S-60°S,DJF)}"

data=case_file(4)
n_forcing=4
set title "GeoB6211-2: Fe"
unset ylabel
unset xlabel
set label 1 "(d)" right at graph 0.97,0.93 front boxed bs 1 font "Nimbus Roman,24"
set key center center maxrows 4 maxcols 1 opaque samplen 0.9 spacing 1.1 font "Nimbus Roman,17.5"
plot \
 data every n_forcing::0 using 1:($12==1?$4:1/0) with linespoints pt 7 ps 0.30 lw 1.2 lc rgb "red" title "{/Symbol D}W_{(30°S,DJF)}", \
 data every n_forcing::1 using 1:($12==1?$4:1/0) with linespoints pt 5 ps 0.30 lw 1.2 lc rgb "orange" title "{/Symbol D}W_{(30°S,SON+DJF)}", \
 data every n_forcing::2 using 1:($12==1?$4:1/0) with linespoints pt 9 ps 0.30 lw 1.2 lc rgb "black" title "{/Symbol D}W_{(30°S,DJF+MAM)}", \
 data every n_forcing::3 using 1:($12==1?$4:1/0) with linespoints pt 11 ps 0.30 lw 1.2 lc rgb "gray" title "MIG_{(30°S-60°S,DJF)}"

data=case_file(5)
n_forcing=3
set title "Palm2: -CaCO_{3}"
unset ylabel
set xlabel "Time [kyBP]" font "Nimbus Roman,32"
set label 1 "(e)" right at graph 0.97,0.93 front boxed bs 1 font "Nimbus Roman,24"
set key center center maxrows 3 maxcols 1 opaque samplen 0.9 spacing 1.1 font "Nimbus Roman,17.5"
plot \
 data every n_forcing::0 using 1:($12==1?$4:1/0) with linespoints pt 7 ps 0.30 lw 1.2 lc rgb "red" title "-{/Symbol D}W_{(60°S,DJF)}", \
 data every n_forcing::1 using 1:($12==1?$4:1/0) with linespoints pt 9 ps 0.30 lw 1.2 lc rgb "black" title "{/Symbol D}W_{(60°S,MAM+JJA)}", \
 data every n_forcing::2 using 1:($12==1?$4:1/0) with linespoints pt 11 ps 0.30 lw 1.2 lc rgb "blue" title "MIG_{(30°-60°S,JJA)}"

data=case_file(6)
n_forcing=3
set title "LA: -{/NimbusRoman-Italic Nothofagus} pollen"
unset ylabel
set xlabel "Time [kyBP]" font "Nimbus Roman,32"
set label 1 "(f)" right at graph 0.97,0.93 front boxed bs 1 font "Nimbus Roman,24"
set key center center maxrows 3 maxcols 1 opaque samplen 0.9 spacing 1.1 font "Nimbus Roman,17.5"
plot \
 data every n_forcing::0 using 1:($12==1?$4:1/0) with linespoints pt 9 ps 0.30 lw 1.2 lc rgb "black" title "-{/Symbol D}W_{(60°S,MAM+JJA)}", \
 data every n_forcing::1 using 1:($12==1?$4:1/0) with linespoints pt 5 ps 0.30 lw 1.2 lc rgb "orange" title "{/Symbol D}W_{(60°S,SON)}", \
 data every n_forcing::2 using 1:($12==1?$4:1/0) with linespoints pt 11 ps 0.30 lw 1.2 lc rgb "blue" title "-MIG_{(30°-60°S,JJA)}"

unset multiplot
unset output
