! Family-wise Monte Carlo probabilities for reconstruction Q and MSE.
! INPUT
!   run.dat: cases, lag limit, CV blocks, surrogate count, seed and local file paths.
!   input/P*.dat and input/F*.dat: the proxy and forcing series used for reconstruction.
!   input/<case>_reconstruction.dat: Q, MSE and selected lags copied manually from
!   RECONSTRUCTION/output/LAG0.x/.
! OUTPUT
!   output/LAG0.x/<case>_surrogates.dat: realization, stage, forcing index, Q and MSE.
!   <case>_family_extrema.dat: maximum Q and minimum MSE for each realization/stage.
!   <case>_statistics.dat: data-derived Q/MSE, event counts, p(Q), p(MSE), final p.
!   <case>_final_modelo_stage.dat: nine-column Q/p(Q) result table.
!   association_summary.csv: all associations and both probabilities.
!   probabilities_other.dat and probabilities_highlighted.dat: Figure 12 coordinates
!   for the descriptive p=0.08 grouping in the zero-lag run.

program monte_carlo
  use iso_fortran_env, only: output_unit
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
  implicit none
  include '../common_declarations.inc' 
  type(run_settings) :: settings
  type(case_definition), allocatable :: cases(:)
  double precision, allocatable :: time(:),y(:),xlag(:,:,:),ys(:),xs(:,:,:),surrogate(:)
  double precision, allocatable :: q_data(:,:),mse_data(:,:),q_null(:),mse_null(:)
  integer, allocatable :: lag_index(:,:),count_q(:,:),count_mse(:,:),count_strict(:,:)
  double complex, allocatable :: spectrum(:),inverse_basis(:,:)
  double precision :: q,mse,sse,sse_ref,maximum_q,minimum_mse,p_q,p_mse,p_final
  integer :: c,s,j,r,n,nf,nlag,nstage,unit,null_unit,family_unit,statistics_unit
  integer :: summary_unit,other_unit,highlight_unit,progress,compatibility_flag,compatibility_marginal
  character(len=path_length) :: prefix,summary_file

  call read_run(settings,cases,.true.)
  ! Check that every configured input is readable before replacing result files.
  do c=1,size(cases)
    call open_old_file(trim(cases(c)%input_file),unit)
    close(unit)
    do j=1,cases(c)%number_forcings
      call open_old_file(trim(cases(c)%forcing_files(j)),unit)
      close(unit)
    end do
    call open_old_file(join_path(trim(settings%reconstruction_directory), &
      trim(cases(c)%name)//'_reconstruction.dat'),unit)
    close(unit)
  end do
  ! One initialization, in the same case order as the established Monte Carlo run.
  call set_reproducible_random_seed(settings%seed)
  summary_file=join_path(trim(settings%output_directory),'association_summary.csv')

  call open_replace_file(trim(summary_file),summary_unit)
  write(summary_unit,'(a)') &
    '# Column 1 = Proxy case name from run.dat.', &
    '# Column 2 = Holocene stage code.', &
    '# Column 3 = Holocene stage name.', &
    '# Column 4 = Local forcing index in run.dat order for this proxy.', &
    '# Column 5 = Forcing label from run.dat.', &
    '# Column 6 = Selected forcing lag [ka].', &
    '# Column 7 = Number of proxy observations in the stage, N.', &
    '# Column 8 = Observed Q [dimensionless].', &
    '# Column 9 = Observed MSE [squared proxy Z score].', &
    '# Column 10 = k_Q: count of family maximum Q >= observed Q - tolerance.', &
    '# Column 11 = k_MSE: count of family minimum MSE <= observed MSE + tolerance.', &
    '# Column 12 = k_MSE_strict: count of family minimum MSE <= observed MSE.', &
    '# Column 13 = p(Q) = (1+k_Q)/(R+1), where R is the surrogate count.', &
    '# Column 14 = p(MSE) = (1+k_MSE)/(R+1).', &
    '# Column 15 = Final probability p = max(p(Q),p(MSE)).', &
    '# Column 12 uses no comparison tolerance; probabilities use Columns 10 and 11.', &
    '# Stage codes: 1 = EH; 2 = MH; 3 = LH.', &
    '# EH > 8.2; MH > 4.2 to 8.2; LH <= 4.2 ka BP1950.'
  write(summary_unit,'(a,es12.4)') '# Comparison tolerance = ',tie_tolerance
  write(summary_unit,'(a)') 'case,stage_code,stage,forcing_index,forcing_label,lag_ka,N,Q,MSE,k_Q,k'// &
    '_MSE,k_MSE_strict,p_Q,p_MSE,p'
  if (settings%maximum_lag_steps==0) then
    call open_replace_file(trim(settings%output_directory)//'/probabilities_other.dat',other_unit)
    call open_replace_file(trim(settings%output_directory)//'/probabilities_highlighted.dat',highlight_unit)
    write(other_unit,'(a)') &
      '# Column 1 = Family-wise Monte Carlo probability p(Q).', &
      '# Column 2 = Family-wise Monte Carlo probability p(MSE).', &
      '# Final probability p = max(p(Q),p(MSE)); both columns are dimensionless.', &
      '# Figure 12 group: final p >= 0.08.'
    write(highlight_unit,'(a)') &
      '# Column 1 = Family-wise Monte Carlo probability p(Q).', &
      '# Column 2 = Family-wise Monte Carlo probability p(MSE).', &
      '# Final probability p = max(p(Q),p(MSE)); both columns are dimensionless.', &
      '# Figure 12 group: final p < 0.08.'
  end if
  do c=1,size(cases)
    call prepare_case(cases(c),settings,time,y,xlag)
    n=size(y); nf=cases(c)%number_forcings; nlag=size(xlag,3)
    allocate(lag_index(nf,n_stages),q_data(nf,n_stages),mse_data(nf,n_stages))
    call read_reconstruction(cases(c),settings,lag_index,q_data,mse_data)
    allocate(count_q(nf,n_stages),count_mse(nf,n_stages),count_strict(nf,n_stages))
    allocate(q_null(nf),mse_null(nf),surrogate(n),spectrum(0:n-1),inverse_basis(0:n-1,0:n-1))
    count_q=0; count_mse=0; count_strict=0
    prefix=join_path(trim(settings%output_directory),trim(cases(c)%name))
    call open_replace_file(trim(prefix)//'_surrogates.dat',null_unit)
    call open_replace_file(trim(prefix)//'_family_extrema.dat',family_unit)
    write(null_unit,'(a)') &
      '# Reconstruction statistics for every Fourier phase surrogate.', &
      '# Column 1 = Surrogate realization index.', &
      '# Column 2 = Holocene stage code.', &
      '# Column 3 = Local forcing index, identified below in run.dat order.', &
      '# Column 4 = Surrogate Q = 1 - SSE/reference_SSE [dimensionless].', &
      '# Column 5 = Surrogate MSE = SSE/N [squared proxy Z score].', &
      '# Stage codes: 1 = EH; 2 = MH; 3 = LH.', &
      '# EH > 8.2; MH > 4.2 to 8.2; LH <= 4.2 ka BP1950.'
    write(null_unit,'(a)') '# Case = '//trim(cases(c)%name)
    do j=1,nf
      write(null_unit,'(a,i0,2a)') '# Forcing ',j,' = ',trim(cases(c)%labels(j))
    end do
    write(family_unit,'(a)') &
      '# Family extrema across the related forcings of one proxy-stage pair.', &
      '# Column 1 = Surrogate realization index.', &
      '# Column 2 = Holocene stage code.', &
      '# Column 3 = Maximum surrogate Q across the family [dimensionless].', &
      '# Column 4 = Minimum surrogate MSE across the family [squared proxy Z score].', &
      '# Stage codes: 1 = EH; 2 = MH; 3 = LH.', &
      '# EH > 8.2; MH > 4.2 to 8.2; LH <= 4.2 ka BP1950.'
    write(family_unit,'(a)') '# Case = '//trim(cases(c)%name)
    call prepare_fourier_transform(y,n,spectrum,inverse_basis)
    progress=max(1,settings%surrogates/10)
    do r=1,settings%surrogates
      ! Generate the whole series first. This consumes exactly the original phase draws.
      call phase_randomize_spectrum(spectrum,inverse_basis,n,surrogate)
      do s=1,n_stages
        call extract_stage(surrogate,time,xlag,n,nf,nlag,s,ys,xs,nstage)
        do j=1,nf
          ! Identical numerical routine to the reconstruction program; fixed lag.
          call reconstruct_stage(ys,xs(:,j,:),nstage,lag_index(j,s),settings%blocks, &
            q_null(j),mse_null(j),sse,sse_ref)
          write(null_unit,'(3(i0,1x),2(es26.17e3,1x))') r,s,j,q_null(j),mse_null(j)
        end do
        maximum_q=maxval(q_null); minimum_mse=minval(mse_null)
        write(family_unit,'(2(i0,1x),2(es26.17e3,1x))') r,s,maximum_q,minimum_mse
        do j=1,nf
          if (maximum_q>=q_data(j,s)-tie_tolerance) count_q(j,s)=count_q(j,s)+1
          if (minimum_mse<=mse_data(j,s)+tie_tolerance) count_mse(j,s)=count_mse(j,s)+1
          if (minimum_mse<=mse_data(j,s)) count_strict(j,s)=count_strict(j,s)+1
        end do
        deallocate(ys,xs)
      end do
      if (mod(r,progress)==0.or.r==settings%surrogates) &
        write(*,'(2a,i0,a,i0)') trim(cases(c)%name),': ',r,' / ',settings%surrogates
    end do
    close(null_unit); close(family_unit)
    call open_replace_file(trim(prefix)//'_final_modelo_stage.dat',unit)
    call open_replace_file(trim(prefix)//'_statistics.dat',statistics_unit)
    write(unit,'(a)') &
      '# Stage reconstruction Q, family-wise p(Q) and display flags.', &
      '# Column 1 = Holocene stage code.', &
      '# Column 2 = Holocene stage name.', &
      '# Column 3 = Local forcing index in run.dat order for this proxy.', &
      '# Column 4 = Forcing label from run.dat.', &
      '# Column 5 = Selected forcing lag [ka].', &
      '# Column 6 = Observed Q [dimensionless].', &
      '# Column 7 = Family-wise Monte Carlo probability p(Q).', &
      '# Column 8 = Display flag: Q >= 0.1 and p(Q) <= 0.05.', &
      '# Column 9 = Display flag: Q >= 0.1 and 0.05 < p(Q) < 0.055.', &
      '# Display flags: 1 = condition met; 0 = otherwise.', &
      '# Stage codes: 1 = EH; 2 = MH; 3 = LH.', &
      '# EH > 8.2; MH > 4.2 to 8.2; LH <= 4.2 ka BP1950.'
    write(unit,'(a)') '# Case = '//trim(cases(c)%name)
    write(statistics_unit,'(a)') &
      '# Observed reconstruction statistics and family-wise Monte Carlo probabilities.', &
      '# Column 1 = Holocene stage code.', &
      '# Column 2 = Local forcing index, identified below in run.dat order.', &
      '# Column 3 = Observed Q [dimensionless].', &
      '# Column 4 = Observed MSE [squared proxy Z score].', &
      '# Column 5 = k_Q: count of family maximum Q >= observed Q - tolerance.', &
      '# Column 6 = k_MSE: count of family minimum MSE <= observed MSE + tolerance.', &
      '# Column 7 = k_MSE_strict: count of family minimum MSE <= observed MSE.', &
      '# Column 8 = p(Q) = (1+k_Q)/(R+1), where R is the surrogate count.', &
      '# Column 9 = p(MSE) = (1+k_MSE)/(R+1).', &
      '# Column 10 = Final probability p = max(p(Q),p(MSE)).', &
      '# Column 7 uses no comparison tolerance; probabilities use Columns 5 and 6.', &
      '# Stage codes: 1 = EH; 2 = MH; 3 = LH.', &
      '# EH > 8.2; MH > 4.2 to 8.2; LH <= 4.2 ka BP1950.'
    write(statistics_unit,'(a)') '# Case = '//trim(cases(c)%name)
    write(statistics_unit,'(a,es12.4)') '# Comparison tolerance = ',tie_tolerance
    do j=1,nf
      write(statistics_unit,'(a,i0,2a)') '# Forcing ',j,' = ',trim(cases(c)%labels(j))
    end do
    do s=1,n_stages
      nstage=count([(stage_from_time(time(r))==s,r=1,n)])
      do j=1,nf
        p_q=dble(1+count_q(j,s))/dble(settings%surrogates+1)
        p_mse=dble(1+count_mse(j,s))/dble(settings%surrogates+1)
        p_final=max(p_q,p_mse)
        ! affect Q, MSE, surrogate counts, either probability or their maximum.
        compatibility_flag=0; compatibility_marginal=0
        if (q_data(j,s)>=0.10d0.and.p_q<=0.05d0) compatibility_flag=1
        if (q_data(j,s)>=0.10d0.and.p_q>0.05d0.and.p_q<0.055d0) compatibility_marginal=1
        write(unit,'(i0,1x,a,1x,i0,1x,a,1x,3(es26.17e3,1x),2(i0,1x))') &
          s,stage_name(s),j,trim(cases(c)%labels(j)), &
          dble(lag_index(j,s)-1)*expected_time_step,q_data(j,s),p_q, &
          compatibility_flag,compatibility_marginal
        write(statistics_unit,'(2(i0,1x),2(es26.17e3,1x),3(i0,1x),3(es26.17e3,1x))') &
          s,j,q_data(j,s),mse_data(j,s),count_q(j,s),count_mse(j,s),count_strict(j,s), &
          p_q,p_mse,p_final
        write(summary_unit,'(*(g0,:,","))') &
          trim(cases(c)%name),s,stage_name(s),j,trim(cases(c)%labels(j)), &
          dble(lag_index(j,s)-1)*expected_time_step,nstage,q_data(j,s),mse_data(j,s), &
          count_q(j,s),count_mse(j,s),count_strict(j,s),p_q,p_mse,p_final
        if (settings%maximum_lag_steps==0) then
          ! This grouping only reproduces the figure's descriptive display convention.
          if (p_final<0.08d0) then
            write(highlight_unit,'(2(es26.17e3,1x))') p_q,p_mse
          else
            write(other_unit,'(2(es26.17e3,1x))') p_q,p_mse
          end if
        end if
      end do
    end do
    close(unit); close(statistics_unit)
    deallocate(time,y,xlag,lag_index,q_data,mse_data,count_q,count_mse,count_strict)
    deallocate(q_null,mse_null,surrogate,spectrum,inverse_basis)
  end do
  close(summary_unit)
  if (settings%maximum_lag_steps==0) then
    close(other_unit); close(highlight_unit)
  end if
contains
  include '../common_procedures.inc'
end program monte_carlo
