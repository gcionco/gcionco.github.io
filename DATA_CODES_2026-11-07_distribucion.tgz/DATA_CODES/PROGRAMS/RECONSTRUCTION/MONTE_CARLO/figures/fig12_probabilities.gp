#!/usr/bin/gnuplot
# Family-wise probability comparison.
# INPUT
#   ../output/LAG0.0/probabilities_other.dat and probabilities_highlighted.dat.
#   Columns: 1 p(Q), 2 p(MSE).
# OUTPUT
#   FIG12.pdf (paper Figure 12).

if (exists("ARG0")) {
    plot_directory = ""
    do for [path_position = strlen(ARG0):1:-1] {
        if (ARG0[path_position:path_position] eq "/" && strlen(plot_directory) == 0) {
            plot_directory = ARG0[1:path_position]
        }
    }
    if (strlen(plot_directory) > 0) {
        cd plot_directory
    }
}

# Paper Figure 12: empirical family-wise p(Q) and p(MSE).
# Coordinates are read from the joined numerical outputs. Dashed reference lines
# retain the descriptive display cutoff used in the published figure.
reset
set encoding utf8
set terminal pdfcairo enhanced color size 21cm,24.7cm font "Nimbus Roman,24"
set output "FIG12.pdf"
unset logscale
set datafile commentschars "#"
set multiplot
set key off
set border 3 lw 1 lc rgb "#526371"
set tics out nomirror scale 0.4 tc rgb "#24323a"
set grid xtics ytics back lw 0.45 lc rgb "#dfe7eb"
set style textbox opaque margins 0.1,0.1 noborder fillcolor "white"
set lmargin at screen 0.170
set rmargin at screen 0.960
set bmargin at screen 0.720
set tmargin at screen 0.880
set xrange [-0.015:1.02]
set yrange [-0.015:1.02]
set xtics 0,0.2,1 font "Nimbus Roman,24"
set ytics 0,0.2,1 font "Nimbus Roman,24"
set format x "%g"
set format y "%g"
set xlabel "{/:Italic p}({/:Italic Q}_{/:Italic j})" font "Nimbus Roman,28" offset 0,-0.15
set ylabel "{/:Italic p}(MSE_{/:Italic j})" font "Nimbus Roman,28" offset -0.2,0
set object 1 rect from first 0,0 to first 0.08,0.08 back fc rgb "#e8f3f2" fs solid 1 noborder
set arrow 1 from first 0.08,graph 0 to first 0.08,graph 1 nohead dt (6,5) lw 1.1 lc rgb "#14757a"
set arrow 2 from graph 0,first 0.08 to graph 1,first 0.08 nohead dt (6,5) lw 1.1 lc rgb "#14757a"
set label 10 "Out-of-sample evaluation" at screen 0.55,0.975 center font "Nimbus Roman,26" tc rgb "#24323a"
set label 11 "4999 phase surrogates per proxy" at screen 0.55,0.94 center font "Nimbus Roman,24" tc rgb "#24323a"
set label 13 "(a) All 78 associations" at screen 0.170,0.905 font "Nimbus Roman,24" tc rgb "#24323a"



plot "../output/LAG0.0/probabilities_other.dat" using 1:2 with points pt 7 ps 0.75 lc rgb "#99a3ad", \
     "../output/LAG0.0/probabilities_highlighted.dat" using 1:2 with points pt 7 ps 0.75 lc rgb "#14757a"
unset label
unset arrow
unset object
set lmargin at screen 0.170
set rmargin at screen 0.960
set bmargin at screen 0.365
set tmargin at screen 0.525
set xrange [-0.001:0.085]
set yrange [-0.001:0.085]
set xtics 0,0.02,0.08 font "Nimbus Roman,24"
set ytics 0,0.02,0.08 font "Nimbus Roman,24"
set xlabel "{/:Italic p}({/:Italic Q}_{/:Italic j})" font "Nimbus Roman,28" offset 0,-0.15
set ylabel "{/:Italic p}(MSE_{/:Italic j})" font "Nimbus Roman,28" offset -0.2,0
set object 1 rect from first 0,0 to first 0.08,0.08 back fc rgb "#e8f3f2" fs solid 1 noborder
set arrow 1 from first 0.08,graph 0 to first 0.08,graph 1 nohead dt (6,5) lw 1.1 lc rgb "#14757a"
set arrow 2 from graph 0,first 0.08 to graph 1,first 0.08 nohead dt (6,5) lw 1.1 lc rgb "#14757a"
set label 1 "(b) Enlargement of the shaded region" at screen 0.170,0.585 font "Nimbus Roman,24" tc rgb "#24323a"
set label 2 "Dashed reference lines: {/:Italic p}({/:Italic Q}_{/:Italic j}), {/:Italic p}(MSE_{/:Italic j}) = 0.08" at screen 0.170,0.550 font "Nimbus Roman,24" tc rgb "#14757a"
set label 3 "{/:Bold Eight associations:} {/:Italic p} < 0.08" at screen 0.060,0.265 font "Nimbus Roman,22" tc rgb "#14757a"
set label 21 "{/:Bold 1  −BTV2 −δ^{18}O · EH}\n    ΔW(30°S, DJF+MAM)" at screen 0.060,0.220 left font "Nimbus Roman,20" tc rgb "#24323a"
set label 22 "{/:Bold 2  −BTV2 −δ^{18}O · EH}\n    ΔW(30°S, SON+DJF)" at screen 0.060,0.165 left font "Nimbus Roman,20" tc rgb "#24323a"
set label 23 "{/:Bold 3  −BTV3A −δ^{18}O · LH}\n    ΔW(30°S, DJF)" at screen 0.060,0.110 left font "Nimbus Roman,20" tc rgb "#24323a"
set label 24 "{/:Bold 4  GeoB6211–2 Al/Si · LH}\n    ΔW(30°S, DJF+MAM)" at screen 0.060,0.055 left font "Nimbus Roman,20" tc rgb "#24323a"
set label 25 "{/:Bold 5  GeoB6211–2 Al/Si · LH}\n    MIG(30°S–60°S, DJF)" at screen 0.555,0.220 left font "Nimbus Roman,20" tc rgb "#24323a"
set label 26 "{/:Bold 6  Palm2 −CaCO_3 · EH}\n    −ΔW(60°S, DJF)" at screen 0.555,0.165 left font "Nimbus Roman,20" tc rgb "#24323a"
set label 27 "{/:Bold 7  Palm2 −CaCO_3 · EH}\n    MIG(30°S–60°S, JJA)" at screen 0.555,0.110 left font "Nimbus Roman,20" tc rgb "#24323a"
set label 28 "{/:Bold 8  LA −{/:Italic Nothofagus} · MH}\n    ΔW(60°S, SON)" at screen 0.555,0.055 left font "Nimbus Roman,20" tc rgb "#24323a"
set arrow 101 from first 0.014,0.019999999999999997 to first 0.0248,0.0002 nohead lw 1 lc rgb "#14757a" front
set label 101 "1" at first 0.014,0.022 center font "Nimbus Roman,24" tc rgb "#14757a" front boxed
set arrow 102 from first 0.064,0.015000000000000001 to first 0.0526,0.0002 nohead lw 1 lc rgb "#14757a" front
set label 102 "2" at first 0.064,0.017 center font "Nimbus Roman,24" tc rgb "#14757a" front boxed
set arrow 103 from first 0.008,0.006999999999999999 to first 0.0002,0.0002 nohead lw 1 lc rgb "#14757a" front
set label 103 "3,8" at first 0.008,0.009 center font "Nimbus Roman,24" tc rgb "#14757a" front boxed
set arrow 104 from first 0.057,0.056999999999999995 to first 0.0352,0.0672 nohead lw 1 lc rgb "#14757a" front
set label 104 "4" at first 0.057,0.059 center font "Nimbus Roman,24" tc rgb "#14757a" front boxed
set arrow 105 from first 0.063,0.075 to first 0.039,0.078 nohead lw 1 lc rgb "#14757a" front
set label 105 "5" at first 0.063,0.077 center font "Nimbus Roman,24" tc rgb "#14757a" front boxed
set arrow 106 from first 0.028,0.032 to first 0.0292,0.0002 nohead lw 1 lc rgb "#14757a" front
set label 106 "6" at first 0.028,0.034 center font "Nimbus Roman,24" tc rgb "#14757a" front boxed
set arrow 107 from first 0.043,0.022 to first 0.0304,0.0002 nohead lw 1 lc rgb "#14757a" front
set label 107 "7" at first 0.043,0.024 center font "Nimbus Roman,24" tc rgb "#14757a" front boxed
plot "../output/LAG0.0/probabilities_highlighted.dat" using 1:2 with points pt 7 ps 0.75 lc rgb "#14757a"
unset multiplot
unset output
