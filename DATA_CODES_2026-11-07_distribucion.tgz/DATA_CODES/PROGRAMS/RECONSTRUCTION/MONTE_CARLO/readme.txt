MONTE CARLO RECONSTRUCTION PROBABILITIES
----------------------------------------

run.dat sets cases, maximum lag, CV blocks, surrogate count, seed, paths and signs.
The two parent common_*.inc files provide the shared reconstruction routines.

BEFORE RUNNING
Requires a completed P_F_association run for the chosen maximum lag and CV blocks.
Copy each <case>_reconstruction.dat manually from ../output/LAG0.x/ to input/.
Also copy the same P*.dat and F*.dat used by that reconstruction into input/.
If all these files are present and match run.dat, run directly.

INPUT
input/P*.dat and F*.dat: the same proxy/forcing series used for reconstruction.
Columns: age [ka BP1950], Z score.
input/<case>_reconstruction.dat: results from ../output/LAG0.x/.
Cases, signs, forcing order, maximum lag and CV blocks must match the reconstruction.

OUTPUT
Each output table includes # Column N = ... lines defining its columns.
Program readers and GNUPLOT scripts skip lines beginning with #.
For association_summary.csv, skip the initial # lines before reading the CSV
field-name row and comma-separated data.
All files are written inside output/LAG0.x/ for the configured maximum lag.
<case>_surrogates.dat: realization, stage code, forcing index, Q, MSE.
<case>_family_extrema.dat: realization, stage code, family maximum Q, minimum MSE.
<case>_statistics.dat columns:
  1 stage code; 2 forcing index; 3 Q; 4 MSE; 5 family Q count;
  6 family MSE count; 7 strict MSE count; 8 p(Q); 9 p(MSE); 10 final p.
association_summary.csv: all associations; case, stage code/name, forcing
index/label, lag, N, Q, MSE, k_Q, k_MSE, k_MSE_strict, p_Q, p_MSE, p.
<case>_final_modelo_stage.dat: stage code/name, forcing index/label, lag, Q, p(Q),
then two earlier display flags: Q>=0.1 with p(Q)<=0.05, or 0.05<p(Q)<0.055.
For zero lag, probabilities_other.dat and probabilities_highlighted.dat contain
p(Q),p(MSE) coordinates for FIG12, grouped by final p>=0.08 or p<0.08.
Stage codes: 1=EH, 2=MH, 3=LH. Forcing order follows run.dat.

METHOD
Randomize Fourier phases of the complete proxy series, retaining amplitudes;
then select stages. Forcings and saved lags remain fixed. A family contains the
related forcings for one proxy-stage pair. Count family Q maxima >= data Q and
MSE minima <= data MSE with tolerance 1e-10; also retain strict MSE counts.
With R surrogates and event count k, p=(1+k)/(R+1).
Final p=max(p(Q),p(MSE)); no independence assumption is made.

FIGURE
After completing the zero-lag Monte Carlo run, from figures/:
  ./fig12_probabilities.gp      FIG12.pdf.
The GNUPLOT script reads the two probability files in output/LAG0.0/.
