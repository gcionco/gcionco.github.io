#!/usr/bin/gnuplot
# Q sensitivity to maximum permitted lag.
# INPUT
#   ../output/LAG0.0 through LAG0.9/*_reconstruction.dat.
#   Columns: stage=1, forcing index=3, selected lag=5, Q=6.
# OUTPUT
#   FIG9.pdf (BTV2), FIG10.pdf (Laguna Azul).

if (exists("ARG0")) {
    plot_directory = ""
    do for [path_position = strlen(ARG0):1:-1] {
        if (ARG0[path_position:path_position] eq "/" && strlen(plot_directory) == 0) {
            plot_directory = ARG0[1:path_position]
        }
    }
    if (strlen(plot_directory) > 0) {
        cd plot_directory
    }
}

# Paper Figures 9--10: Q against the permitted maximum lag.
# BTV2 is Figure 9; Laguna Azul is Figure 10.
# Read the ten reconstruction runs. No Monte Carlo run is needed for Q.
# Each maximum lag is configured manually in RECONSTRUCTION/run.dat.
do for [lag_index=0:9] {
    do for [case_index=1:2] {
        required_case = (case_index==1 ? "BTV2_Cruz_NEG_d18O" : "LagunaAzul_NEG_Nothofagus")
        required_file = sprintf("../output/LAG%.1f/%s_reconstruction.dat",lag_index/10.0,required_case)
        STATS_records = 0
        stats required_file using 6 nooutput
        if (STATS_records==0) {
            print sprintf("Missing or empty input: %s",required_file)
            print sprintf("Run P_F_association.exe with maximum_lag = %.1f in run.dat.",lag_index/10.0)
            exit error "The ten reconstruction runs are required for Figures 9 and 10."
        }
    }
}
set terminal pdfcairo size 21cm,24.7cm font "Nimbus Roman,24" enhanced color
set encoding utf8
set datafile commentschars "#"
set border 3
set tics out nomirror font "Nimbus Roman,24"
set title font "Nimbus Roman,26"
set xlabel font "Nimbus Roman,32"
set ylabel font "Nimbus Roman,32"
set lmargin at screen 0.13
set rmargin at screen 0.57
set xrange [-0.02:0.92]
set xtics 0.0,0.1,0.9
set grid xtics ytics back lc rgb "#dddddd" lw 0.6
set xlabel "{/NimbusRoman-Italic τ}_{M} [kyr]" font "Nimbus Roman,32"
set ylabel "{/NimbusRoman-Italic Q}_{/NimbusRoman-Italic j}" font "Nimbus Roman,32"
unset key

set arrow 1 from graph 0, first 0 to graph 1, first 0 nohead \
    lc rgb "#555555" lw 1.2 dt (3,3) front

array stage_name[3]
stage_name[1] = "EH"
stage_name[2] = "MH"
stage_name[3] = "LH"
array forcing_label[6]
array forcing_color[6]
array minimum_tau[6]
array maximum_tau[6]
array tau_changes[6]

# The internal plotting table holds lag limit, stage, forcing, selected lag and Q.
prepare_tau_summary = "do for [f=1:nf] { stats $lag_data using (($2==s && $3==f)?$4:1/0) nooutput; minimum_tau[f]=STATS_min; maximum_tau[f]=STATS_max; tau_changes[f]=(abs(STATS_max-STATS_min)>1.0e-10) }"

plot_stage = "plot for [f=1:nf] $lag_data using (($2==s && $3==f)?$1:1/0):5 with linespoints lw 2.2 pt 7 ps 0.78 lc rgb forcing_color[f] notitle"

case_name = "BTV2_Cruz_NEG_d18O"
nf = 6
forcing_label[1] = "ΔW_{(30°S,DJF)}"
forcing_label[2] = "ΔW_{(30°S,SON+DJF)}"
forcing_label[3] = "ΔW_{(30°S,DJF+MAM)}"
forcing_label[4] = "ΔW_{(30°S,S+DJF+M)}"
forcing_label[5] = "-MIG_{(0°-30°S,DJF)}"
forcing_label[6] = "MIG_{(30°S-30°N,DJF)}"
forcing_color[1] = "red"
forcing_color[2] = "orange"
forcing_color[3] = "black"
forcing_color[4] = "blue"
forcing_color[5] = "magenta"
forcing_color[6] = "#666666"
# Read selected lag and Q directly from the reconstruction files.
set print $lag_data
do for [stage_index=1:3] {
    do for [forcing_index=1:nf] {
        do for [lag_index=0:9] {
            result_file = sprintf("../output/LAG%.1f/%s_reconstruction.dat",lag_index/10.0,case_name)
            STATS_records = 0
            stats result_file using (($1==stage_index && $3==forcing_index)?$5:1/0):6 nooutput
            if (STATS_records!=1) {
                set print
                print sprintf("Expected one row for stage %d, forcing %d in %s",stage_index,forcing_index,result_file)
                exit error "Invalid reconstruction input for the lag figure."
            }
            print sprintf("%.1f %d %d %.17g %.17g",lag_index/10.0,stage_index,forcing_index,STATS_min_x,STATS_min_y)
        }
    }
}
set print

set yrange [-1.1:1.1]
set ytics autofreq
set output "FIG9.pdf"
set multiplot layout 3,1 rowsfirst margins 0.13,0.57,0.10,0.92 spacing 0.07,0.10 title "-BTV2: -δ^{18}O" font "Nimbus Roman,26"
do for [s=1:3] {
    @prepare_tau_summary
    unset label
    unset arrow
    set arrow 1 from graph 0, first 0 to graph 1, first 0 nohead lc rgb "#555555" lw 1.2 dt (3,3) front
    do for [f=1:nf] {
        legend_y = 0.8166666667-(s-1)*0.3066666667+((nf+1)/2.0-f)*0.037
        set arrow (100+f) from screen 0.590,legend_y to screen 0.630,legend_y nohead lw 2.2 lc rgb forcing_color[f] front
        set label (100+f) forcing_label[f] at screen 0.650,legend_y left font "Nimbus Roman,20" front
        lag_label = (tau_changes[f] ? sprintf("[{/NimbusRoman-Italic τ}_{j} =%.1f–%.1f kyr]",minimum_tau[f],maximum_tau[f]) : sprintf("[{/NimbusRoman-Italic τ}_{j} =%.1f kyr]",minimum_tau[f]))
        set label (200+f) lag_label at screen 0.850,legend_y left font "Nimbus Roman,18" front
    }
    if (s<3) { unset xlabel } else { set xlabel "{/NimbusRoman-Italic τ}_{M} [kyr]" font "Nimbus Roman,32" }
    set title stage_name[s] offset 0,-0.8
    @plot_stage
}
unset multiplot
unset output


case_name = "LagunaAzul_NEG_Nothofagus"
nf = 3
forcing_label[1] = "-ΔW_{(60°S,MAM+JJA)}"
forcing_label[2] = "ΔW_{(60°S,SON)}"
forcing_label[3] = "-MIG_{(30°S-60°S,JJA)}"
forcing_color[1] = "black"
forcing_color[2] = "orange"
forcing_color[3] = "blue"
# Read selected lag and Q directly from the reconstruction files.
set print $lag_data
do for [stage_index=1:3] {
    do for [forcing_index=1:nf] {
        do for [lag_index=0:9] {
            result_file = sprintf("../output/LAG%.1f/%s_reconstruction.dat",lag_index/10.0,case_name)
            STATS_records = 0
            stats result_file using (($1==stage_index && $3==forcing_index)?$5:1/0):6 nooutput
            if (STATS_records!=1) {
                set print
                print sprintf("Expected one row for stage %d, forcing %d in %s",stage_index,forcing_index,result_file)
                exit error "Invalid reconstruction input for the lag figure."
            }
            print sprintf("%.1f %d %d %.17g %.17g",lag_index/10.0,stage_index,forcing_index,STATS_min_x,STATS_min_y)
        }
    }
}
set print

set yrange [-0.4:1.1]
set ytics autofreq
set output "FIG10.pdf"
set multiplot layout 3,1 rowsfirst margins 0.13,0.57,0.10,0.92 spacing 0.07,0.10 title "Laguna Azul: -{/NimbusRoman-Italic Nothofagus}" font "Nimbus Roman,26"
do for [s=1:3] {
    @prepare_tau_summary
    unset label
    unset arrow
    set arrow 1 from graph 0, first 0 to graph 1, first 0 nohead lc rgb "#555555" lw 1.2 dt (3,3) front
    do for [f=1:nf] {
        legend_y = 0.8166666667-(s-1)*0.3066666667+((nf+1)/2.0-f)*0.037
        set arrow (100+f) from screen 0.590,legend_y to screen 0.630,legend_y nohead lw 2.2 lc rgb forcing_color[f] front
        set label (100+f) forcing_label[f] at screen 0.650,legend_y left font "Nimbus Roman,20" front
        lag_label = (tau_changes[f] ? sprintf("[{/NimbusRoman-Italic τ}_{j} =%.1f–%.1f kyr]",minimum_tau[f],maximum_tau[f]) : sprintf("[{/NimbusRoman-Italic τ}_{j} =%.1f kyr]",minimum_tau[f]))
        set label (200+f) lag_label at screen 0.850,legend_y left font "Nimbus Roman,18" front
    }
    if (s<3) { unset xlabel } else { set xlabel "{/NimbusRoman-Italic τ}_{M} [kyr]" font "Nimbus Roman,32" }
    set title stage_name[s] offset 0,-0.8
    @plot_stage
}
unset multiplot
unset output

print "FIG9.pdf and FIG10.pdf"
