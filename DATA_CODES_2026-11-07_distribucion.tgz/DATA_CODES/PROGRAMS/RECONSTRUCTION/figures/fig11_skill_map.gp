#!/usr/bin/gnuplot
# Stage-wise Q map.
# INPUT
#   ../output/LAG0.0/*_reconstruction.dat; Q in column 6.
# OUTPUT
#   FIG11.pdf (paper Figure 11).

if (exists("ARG0")) {
    plot_directory = ""
    do for [path_position = strlen(ARG0):1:-1] {
        if (ARG0[path_position:path_position] eq "/" && strlen(plot_directory) == 0) {
            plot_directory = ARG0[1:path_position]
        }
    }
    if (strlen(plot_directory) > 0) {
        cd plot_directory
    }
}

# Paper Figure 11: Q for each proxy-stage-forcing association.
# Crosses/circle/triangles reproduce the paper display annotations; their values
# are reported in the complete association summary. They do not alter Q.
lag_text = "0.0"

set terminal pdfcairo size 21cm,24.7cm font "Nimbus Roman,24" enhanced color
set output "FIG11.pdf"
set datafile commentschars "#"
set encoding utf8
set border 3
set tics out nomirror
set xtics font "Nimbus Roman,22"
set ytics font "Nimbus Roman,20"
set cbtics font "Nimbus Roman,20"
set title font "Nimbus Roman,24"
set title offset 0,-0.5
set xlabel font "Nimbus Roman,32"
set cblabel font "Nimbus Roman,26"
set cbtics 0.25
set cblabel offset -0.5,0

set xrange [3.5:0.5]

set cbrange [-0.50:1.00]
set palette defined (-0.50 "#b2182b", \
                      0.00 "#f7f7f7", \
                      0.10 "#d1e5f0", \
                      0.50 "#67a9cf", \
                      1.00 "#2166ac")
unset cblabel
unset colorbox
set xtics ("EH" 1, "MH" 2, "LH" 3)
unset xlabel
unset ylabel
set pointsize 1.0
unset key

$JOINT_SELECTION_1 << EOD
1 3
EOD

$JOINT_SELECTION_2 << EOD
3 1
EOD

$JOINT_SELECTION_3 << EOD
3 3
3 4
EOD

$JOINT_SELECTION_5 << EOD
1 1
1 3
EOD

$JOINT_SELECTION_6 << EOD
2 2
EOD

$BTV2_CIRCLE << EOD
1 2
EOD
$FE_TRIANGLES << EOD
3 3
3 4
EOD

set multiplot layout 3,2 rowsfirst
result_file = "../output/LAG0.0/BTV2_Cruz_NEG_d18O_reconstruction.dat"
set title "-BTV2: -δ^{18}O"
set yrange [0.5:6.5]
n_forcing = 6
set ytics ("ΔW_{(30°S,DJF)}" 1, \
           "ΔW_{(30°S,SON+DJF)}" 2, \
           "ΔW_{(30°S,DJF+MAM)}" 3, \
           "ΔW_{(30°S,S+DJF+M)}" 4, \
           "-MIG_{(0°-30°S,DJF)}" 5, \
           "MIG_{(30°S-30°N,DJF)}" 6)

set lmargin at screen 0.195
set rmargin at screen 0.480
set bmargin at screen 0.725
set tmargin at screen 0.920
unset cblabel
unset xlabel
unset arrow
do for [k=1:2] { set arrow (500+k) from first k+0.5,graph 0 to first k+0.5,graph 1 nohead lw 2.5 lc rgb "white" front }
do for [k=1:n_forcing-1] { set arrow (510+k) from graph 0,first k+0.5 to graph 1,first k+0.5 nohead lw 2.5 lc rgb "white" front }
set arrow 530 from graph 0,0 to graph 1,0 nohead lw 2.5 lc rgb "white" front
set arrow 531 from graph 0,1 to graph 1,1 nohead lw 2.5 lc rgb "white" front
set arrow 532 from graph 0,0 to graph 0,1 nohead lw 2.5 lc rgb "white" front
set arrow 533 from graph 1,0 to graph 1,1 nohead lw 2.5 lc rgb "white" front
plot result_file u 1:3:6 with image notitle, \
     $JOINT_SELECTION_1 using 1:2 with points pt 2 ps 2.1 lw 7.5 lc rgb "white" notitle, \
     $JOINT_SELECTION_1 using 1:2 with points pt 2 ps 2.1 lw 3.6 lc rgb "black" notitle, \
     $BTV2_CIRCLE using 1:2 with points pt 6 ps 2.17 lw 7.5 lc rgb "white" notitle, \
     $BTV2_CIRCLE using 1:2 with points pt 6 ps 2.17 lw 3.6 lc rgb "black" notitle

result_file = "../output/LAG0.0/BTV3A_Wang_NEG_d18O_reconstruction.dat"
set title "-BTV3A: -δ^{18}O"

set lmargin at screen 0.695
set rmargin at screen 0.980
set bmargin at screen 0.725
set tmargin at screen 0.920
unset xlabel
unset arrow
do for [k=1:2] { set arrow (500+k) from first k+0.5,graph 0 to first k+0.5,graph 1 nohead lw 2.5 lc rgb "white" front }
do for [k=1:n_forcing-1] { set arrow (510+k) from graph 0,first k+0.5 to graph 1,first k+0.5 nohead lw 2.5 lc rgb "white" front }
set arrow 530 from graph 0,0 to graph 1,0 nohead lw 2.5 lc rgb "white" front
set arrow 531 from graph 0,1 to graph 1,1 nohead lw 2.5 lc rgb "white" front
set arrow 532 from graph 0,0 to graph 0,1 nohead lw 2.5 lc rgb "white" front
set arrow 533 from graph 1,0 to graph 1,1 nohead lw 2.5 lc rgb "white" front
plot result_file u 1:3:6 with image notitle, \
     $JOINT_SELECTION_2 using 1:2 with points pt 2 ps 2.1 lw 7.5 lc rgb "white" notitle, \
     $JOINT_SELECTION_2 using 1:2 with points pt 2 ps 2.1 lw 3.6 lc rgb "black" notitle

result_file = "../output/LAG0.0/GeoB_AlSi_reconstruction.dat"
set title "GeoB6211-2: Al/Si"
set yrange [0.5:4.5]
n_forcing = 4
set ytics ("ΔW_{(30°S,DJF)}" 1, \
           "ΔW_{(30°S,SON+DJF)}" 2, \
           "ΔW_{(30°S,DJF+MAM)}" 3, \
           "MIG_{(30°S-60°S,DJF)}" 4)

set lmargin at screen 0.195
set rmargin at screen 0.480
set bmargin at screen 0.440
set tmargin at screen 0.620
unset cblabel
unset xlabel
unset arrow
do for [k=1:2] { set arrow (500+k) from first k+0.5,graph 0 to first k+0.5,graph 1 nohead lw 2.5 lc rgb "white" front }
do for [k=1:n_forcing-1] { set arrow (510+k) from graph 0,first k+0.5 to graph 1,first k+0.5 nohead lw 2.5 lc rgb "white" front }
set arrow 530 from graph 0,0 to graph 1,0 nohead lw 2.5 lc rgb "white" front
set arrow 531 from graph 0,1 to graph 1,1 nohead lw 2.5 lc rgb "white" front
set arrow 532 from graph 0,0 to graph 0,1 nohead lw 2.5 lc rgb "white" front
set arrow 533 from graph 1,0 to graph 1,1 nohead lw 2.5 lc rgb "white" front
plot result_file u 1:3:6 with image notitle, \
     $JOINT_SELECTION_3 using 1:2 with points pt 2 ps 2.1 lw 7.5 lc rgb "white" notitle, \
     $JOINT_SELECTION_3 using 1:2 with points pt 2 ps 2.1 lw 3.6 lc rgb "black" notitle

result_file = "../output/LAG0.0/GeoB_Fe_reconstruction.dat"
set title "GeoB6211-2: Fe"

set lmargin at screen 0.695
set rmargin at screen 0.980
set bmargin at screen 0.440
set tmargin at screen 0.620
unset xlabel
unset arrow
do for [k=1:2] { set arrow (500+k) from first k+0.5,graph 0 to first k+0.5,graph 1 nohead lw 2.5 lc rgb "white" front }
do for [k=1:n_forcing-1] { set arrow (510+k) from graph 0,first k+0.5 to graph 1,first k+0.5 nohead lw 2.5 lc rgb "white" front }
set arrow 530 from graph 0,0 to graph 1,0 nohead lw 2.5 lc rgb "white" front
set arrow 531 from graph 0,1 to graph 1,1 nohead lw 2.5 lc rgb "white" front
set arrow 532 from graph 0,0 to graph 0,1 nohead lw 2.5 lc rgb "white" front
set arrow 533 from graph 1,0 to graph 1,1 nohead lw 2.5 lc rgb "white" front
plot result_file u 1:3:6 with image notitle, \
     $FE_TRIANGLES using 1:2 with points pt 8 ps 2.24 lw 7.5 lc rgb "white" notitle, \
     $FE_TRIANGLES using 1:2 with points pt 8 ps 2.24 lw 3.6 lc rgb "black" notitle

result_file = "../output/LAG0.0/Palm2_NEG_CaCO3_reconstruction.dat"
set title "Palm2: -CaCO_3"
set yrange [0.5:3.5]
n_forcing = 3
set ytics ("-ΔW_{(60°S,DJF)}" 1, \
           "ΔW_{(60°S,MAM+JJA)}" 2, \
           "MIG_{(30°S-60°S,JJA)}" 3)

set lmargin at screen 0.195
set rmargin at screen 0.480
set bmargin at screen 0.185
set tmargin at screen 0.330
unset cblabel
set xlabel "Holocene stage" font "Nimbus Roman,24"
unset arrow
do for [k=1:2] { set arrow (500+k) from first k+0.5,graph 0 to first k+0.5,graph 1 nohead lw 2.5 lc rgb "white" front }
do for [k=1:n_forcing-1] { set arrow (510+k) from graph 0,first k+0.5 to graph 1,first k+0.5 nohead lw 2.5 lc rgb "white" front }
set arrow 530 from graph 0,0 to graph 1,0 nohead lw 2.5 lc rgb "white" front
set arrow 531 from graph 0,1 to graph 1,1 nohead lw 2.5 lc rgb "white" front
set arrow 532 from graph 0,0 to graph 0,1 nohead lw 2.5 lc rgb "white" front
set arrow 533 from graph 1,0 to graph 1,1 nohead lw 2.5 lc rgb "white" front
plot result_file u 1:3:6 with image notitle, \
     $JOINT_SELECTION_5 using 1:2 with points pt 2 ps 2.1 lw 7.5 lc rgb "white" notitle, \
     $JOINT_SELECTION_5 using 1:2 with points pt 2 ps 2.1 lw 3.6 lc rgb "black" notitle

result_file = "../output/LAG0.0/LagunaAzul_NEG_Nothofagus_reconstruction.dat"
set title "LA: -{/NimbusRoman-Italic Nothofagus}"
set ytics ("-ΔW_{(60°S,MAM+JJA)}" 1, \
           "ΔW_{(60°S,SON)}" 2, \
           "-MIG_{(30°S-60°S,JJA)}" 3)

set lmargin at screen 0.695
set rmargin at screen 0.980
set bmargin at screen 0.185
set tmargin at screen 0.330
set xlabel "Holocene stage" font "Nimbus Roman,24"
set colorbox horizontal user origin 0.195,0.045 size 0.785,0.014
unset cblabel
set label 100 "{/NimbusRoman-Italic Q_{j}}" at screen 0.160,0.05 right font "Nimbus Roman,26"
unset arrow
do for [k=1:2] { set arrow (500+k) from first k+0.5,graph 0 to first k+0.5,graph 1 nohead lw 2.5 lc rgb "white" front }
do for [k=1:n_forcing-1] { set arrow (510+k) from graph 0,first k+0.5 to graph 1,first k+0.5 nohead lw 2.5 lc rgb "white" front }
set arrow 530 from graph 0,0 to graph 1,0 nohead lw 2.5 lc rgb "white" front
set arrow 531 from graph 0,1 to graph 1,1 nohead lw 2.5 lc rgb "white" front
set arrow 532 from graph 0,0 to graph 0,1 nohead lw 2.5 lc rgb "white" front
set arrow 533 from graph 1,0 to graph 1,1 nohead lw 2.5 lc rgb "white" front
plot result_file u 1:3:6 with image notitle, \
     $JOINT_SELECTION_6 using 1:2 with points pt 2 ps 2.1 lw 7.5 lc rgb "white" notitle, \
     $JOINT_SELECTION_6 using 1:2 with points pt 2 ps 2.1 lw 3.6 lc rgb "black" notitle

unset multiplot
unset output
