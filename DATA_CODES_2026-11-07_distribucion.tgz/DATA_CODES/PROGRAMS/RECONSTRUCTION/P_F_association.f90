! Temporal-block reconstruction of proxy trends using individual forcing curves.
! INPUT
!   run.dat: cases, lag limit, CV blocks, paths, forcing labels and sign multipliers.
!   input/P*.dat: filtered proxies; age [ka BP1950], proxy Z score.
!   input/F*.dat: forcing curves; time [ka BP1950], forcing Z score.
! OUTPUT
!   output/LAG0.x/<case>_reconstruction.dat: selected lag, Q, MSE, SSE, reference SSE,
!   N and full-stage OLS intercept/slope for every stage and related forcing.
!   output/LAG0.x/<case>_predictions.dat: withheld predictions, reference and block fits.
! METHOD
!   Select the forcing lag by full-stage OLS MSE, then keep it fixed.
!   Refit OLS outside each temporal block and predict the withheld proxy values.
!   Calculate Q and MSE from the same complete set of withheld predictions.
! SHARED ROUTINES
!   common_declarations.inc and common_procedures.inc are also used by MONTE_CARLO.
! OLS LOCATION
!   fit_ols in common_procedures.inc calculates the intercept and slope.
!   select_ols_lag -> fit_ols: fit the complete stage for each candidate lag.
!   reconstruct_stage -> fit_ols: fit outside each withheld temporal block.
!   OLS routine is based on NUMERICAL RECIPES FIT routine 

! AUTHOR: R. G. CIONCO, 2026

program P_F_association

  use iso_fortran_env, only: output_unit
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
  implicit none

!...Shared constants, run settings and proxy/forcing file definitions
  include 'common_declarations.inc'
  type(run_settings) :: settings
  type(case_definition), allocatable :: cases(:)

!...Complete analysis grid: age, proxy P(t) and forcing F(t+lag)
  real*8, allocatable :: time(:),y(:),xlag(:,:,:)

!...One Holocene stage: proxy and lagged forcing values
  real*8, allocatable :: ys(:),xs(:,:,:)

!...Withheld predictions, reference means and fitting-set OLS coefficients
  real*8, allocatable :: prediction(:),reference(:)
  real*8, allocatable :: b0_block(:),b1_block(:)
  logical, allocatable :: all_values(:)

!...Stage statistics and full-stage OLS fit used to select the lag
  real*8 :: q,mse,sse,sse_ref
  real*8 :: b0,b1,alignment_mse

!...Indices: proxy c, stage s, forcing j, stage row k, complete-grid row b
  integer :: c,s,j,k,b
  integer :: n,nf,nlag,nstage,selected_lag
  integer :: unit,prediction_unit
  character(len=path_length) :: prefix

!...Read run.dat and allocate the coefficients stored for each withheld block
  call read_run(settings,cases)
  allocate(b0_block(settings%blocks),b1_block(settings%blocks))

!...Process each proxy with its related forcing curves
  do c=1,size(cases)

    ! Read local inputs, apply their signs and prepare the lagged forcing arrays.
    ! xlag(row,j,1) has zero lag; larger indices sample older forcing ages.
    call prepare_case(cases(c),settings,time,y,xlag)
    n=size(y)
    nf=cases(c)%number_forcings
    nlag=size(xlag,3)

    ! Open the two output tables and describe every column before writing data.
    prefix=join_path(trim(settings%output_directory),trim(cases(c)%name))
    call open_replace_file(trim(prefix)//'_reconstruction.dat',unit)
    call open_replace_file(trim(prefix)//'_predictions.dat',prediction_unit)
    write(unit,'(a)') &
      '# Temporal-block cross-validation reconstruction statistics.', &
      '# Column 1 = Holocene stage code.', &
      '# Column 2 = Holocene stage name.', &
      '# Column 3 = Local forcing index in run.dat order for this proxy.', &
      '# Column 4 = Forcing label from run.dat.', &
      '# Column 5 = Selected forcing lag [ka].', &
      '# Column 6 = Q = 1 - SSE/reference_SSE [dimensionless].', &
      '# Column 7 = MSE = SSE/N [squared proxy Z score].', &
      '# Column 8 = Sum of squared withheld-prediction errors, SSE.', &
      '# Column 9 = Reference SSE using each fitting-set proxy mean.', &
      '# Column 10 = Number of proxy observations in the stage, N.', &
      '# Column 11 = Full-stage OLS intercept [proxy Z score].', &
      '# Column 12 = Full-stage OLS slope [proxy Z score / forcing Z score].', &
      '# SSE and reference SSE are in squared proxy Z-score units.', &
      '# P and F include the sign multipliers specified in run.dat.', &
      '# Stage codes: 1 = EH; 2 = MH; 3 = LH.', &
      '# EH > 8.2; MH > 4.2 to 8.2; LH <= 4.2 ka BP1950.'
    write(unit,'(a)') '# Case = '//trim(cases(c)%name)
    write(prediction_unit,'(a)') &
      '# Individual withheld predictions from temporal-block cross-validation.', &
      '# Column 1 = Holocene stage code.', &
      '# Column 2 = Local forcing index, identified below in run.dat order.', &
      '# Column 3 = Withheld temporal block index within the stage.', &
      '# Column 4 = Age [ka BP1950; present = 1950 CE].', &
      '# Column 5 = Observed proxy P [Z score].', &
      '# Column 6 = Withheld prediction of P [Z score].', &
      '# Column 7 = Mean P in the fitting set, used as reference [Z score].', &
      '# Column 8 = Fitting-set OLS intercept [proxy Z score].', &
      '# Column 9 = Fitting-set OLS slope [proxy Z score / forcing Z score].', &
      '# P and F include the sign multipliers specified in run.dat.', &
      '# Stage codes: 1 = EH; 2 = MH; 3 = LH.', &
      '# EH > 8.2; MH > 4.2 to 8.2; LH <= 4.2 ka BP1950.'
    write(prediction_unit,'(a)') '# Case = '//trim(cases(c)%name)
    do j=1,nf
      write(prediction_unit,'(a,i0,2a)') '# Forcing ',j,' = ',trim(cases(c)%labels(j))
    end do

    ! Extract EH, MH and LH without changing the chronological row order.
    do s=1,n_stages
      call extract_stage(y,time,xlag,n,nf,nlag,s,ys,xs,nstage)
      allocate(all_values(nstage),prediction(nstage),reference(nstage))

      ! Every stage value participates in the initial lag-selection fit.
      all_values=.true.

      do j=1,nf

        ! Select the lag using the complete stage. b0 and b1 describe that fit.
        ! select_ols_lag calls fit_ols in common_procedures.inc for every lag.
        call select_ols_lag(ys,xs(:,j,:),nstage,nlag,all_values,selected_lag,b0,b1,alignment_mse)

        ! Keep the selected lag fixed; refit only OLS coefficients in each CV fold.
        ! The reference for a withheld value is the mean of its fitting set.
        ! reconstruct_stage calls the same fit_ols routine for each fitting set.
        call reconstruct_stage(ys,xs(:,j,:),nstage,selected_lag,settings%blocks, &
          q,mse,sse,sse_ref,prediction,reference,b0_block,b1_block)

        ! Save stage statistics together with the selected full-stage OLS fit.
        write(unit,'(i0,1x,a,1x,i0,1x,a,1x,5(es26.17e3,1x),i0,1x,2(es26.17e3,1x))') &
          s,stage_name(s),j,trim(cases(c)%labels(j)), &
          dble(selected_lag-1)*expected_time_step,q,mse,sse,sse_ref,nstage,b0,b1

        ! Map each stage row k back to its age in the complete grid, indexed by b.
        ! The block index identifies the fitting-set coefficients for that value.
        k=0
        do b=1,n
          if (stage_from_time(time(b))/=s) cycle
          k=k+1
          write(prediction_unit,'(3(i0,1x),6(es26.17e3,1x))') &
            s,j,block_number(k,nstage,settings%blocks),time(b),ys(k),prediction(k),reference(k), &
            b0_block(block_number(k,nstage,settings%blocks)), &
            b1_block(block_number(k,nstage,settings%blocks))
        end do
      end do

      deallocate(all_values,prediction,reference,ys,xs)
    end do

    close(unit)
    close(prediction_unit)
    deallocate(time,y,xlag)
    write(*,'(2a)') 'reconstruction written: ',trim(cases(c)%name)
  end do

contains

  ! Include the same numerical procedures used to evaluate Monte Carlo surrogates.
  include 'common_procedures.inc'

end program P_F_association
